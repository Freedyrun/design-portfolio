const A = {
  icons: "icons/",
  backgrounds: "backgrounds/",
  products: "products/",
  details: "detail-scenes/",
  version: "visual-structure-refresh-20260611",
};

const asset = (path) => `${path}?v=${A.version}`;
const icon = (name) => asset(`${A.icons}${name}.png.webp`);
const bg = (name) => asset(`${A.backgrounds}${name}.png.webp`);
const productImage = (name) => asset(`${A.products}${name}.png.webp`);
const detailScene = (name) => asset(`${A.details}${name}_scene.png.webp`);

const tabs = [
  { id: "home", label: "首页", icon: "tab_home" },
  { id: "coupon", label: "找券", icon: "tab_coupon_search" },
  { id: "share", label: "分享", icon: "tab_share" },
  { id: "earnings", label: "收益", icon: "tab_earnings" },
  { id: "profile", label: "我的", icon: "tab_profile" },
];

const quickItems = [
  ["淘宝优惠券", "coupon_search"],
  ["今日高佣", "high_commission"],
  ["9.9包邮", "free_shipping_99"],
  ["品牌券", "brand_coupon"],
  ["群发助手", "group_send"],
  ["朋友圈素材", "moments_material"],
  ["我的收益", "my_earnings"],
  ["邀请好友", "invite_friend"],
];

const products = [
  {
    id: "air-fryer",
    name: "空气炸锅家用智能多功能无油电炸锅",
    tag: "家电",
    coupon: "券¥30",
    commission: "返¥8.6",
    price: "¥59.9",
    oldPrice: "¥89.9",
    sales: "月销2.3万",
    image: "air_fryer",
    rating: "4.8",
    saving: "¥30",
    highlights: ["大容量可视炸篮", "低脂无油烹饪", "智能定时控温"],
  },
  {
    id: "earbuds",
    name: "真无线蓝牙耳机 降噪运动游戏通用",
    tag: "数码",
    coupon: "券¥20",
    commission: "返¥6.2",
    price: "¥39.9",
    oldPrice: "¥69.9",
    sales: "月销1.6万",
    image: "wireless_earbuds",
    rating: "4.9",
    saving: "¥20",
    highlights: ["主动降噪", "低延迟游戏模式", "长续航充电仓"],
  },
  {
    id: "shoes",
    name: "轻便运动鞋 透气软底",
    tag: "穿搭",
    coupon: "券¥50",
    commission: "返¥12.4",
    price: "¥89",
    oldPrice: "¥129",
    sales: "月销1.8万",
    image: "running_shoes",
    rating: "4.7",
    saving: "¥40",
    highlights: ["轻量透气鞋面", "软弹缓震鞋底", "日常通勤百搭"],
  },
  {
    id: "cleanser",
    name: "氨基酸洁面乳 温和清洁",
    tag: "美妆",
    coupon: "券¥20",
    commission: "返¥5.6",
    price: "¥39.9",
    oldPrice: "¥59.9",
    sales: "月销3.1万",
    image: "facial_cleanser",
    rating: "4.9",
    saving: "¥20",
    highlights: ["氨基酸温和配方", "细腻绵密泡沫", "清洁不紧绷"],
  },
];

const searchProducts = [
  { ...products[3], price: "¥29.9", commission: "返¥4.8", coupon: "券¥20", name: "咖啡滤泡美式纯黑咖啡粉提神" },
  { ...products[1], price: "¥19.9", commission: "返¥2.1", coupon: "券¥10", name: "厨房抽纸整箱家用实惠装面巾纸" },
  { ...products[2], price: "¥79", commission: "返¥9.6", coupon: "券¥40", name: "轻便运动鞋 透气软底防滑" },
];

let activeTab = "home";
let activeView = "tab";
let selectedProductId = products[0].id;

function renderNav() {
  const nav = document.querySelector(".bottom-nav");
  nav.innerHTML = tabs
    .map(
      (tab) => `
        <button class="nav-item ${activeTab === tab.id && activeView === "tab" ? "active" : ""}" data-tab="${tab.id}">
          <img src="${icon(tab.icon)}" alt="" />
          <span>${tab.label}</span>
        </button>
      `,
    )
    .join("");

  nav.querySelectorAll("button").forEach((button) => {
    button.addEventListener("click", () => {
      activeTab = button.dataset.tab;
      activeView = "tab";
      render();
    });
  });
}

function productCard(product) {
  return `
    <article class="product-card" data-detail="${product.id}">
      <div class="product-img">
        <img class="product-photo" src="${productImage(product.image)}" alt="${product.name}" />
      </div>
      <div class="product-body">
        <p class="product-title">${product.name}</p>
        <div class="product-meta">
          <span class="label">${product.coupon}</span>
          <span class="label gold">${product.commission}</span>
        </div>
        <div class="price-row">
          <div class="price-stack"><span class="price">${product.price}</span><del>${product.oldPrice}</del></div>
          <button class="share-btn" data-share>分享赚</button>
        </div>
        <div class="sales">${product.tag} · ${product.sales}</div>
      </div>
    </article>
  `;
}

function searchResult(product) {
  return `
    <article class="result-card" data-detail="${product.id}">
      <img src="${productImage(product.image)}" alt="${product.name}" />
      <div>
        <h3>${product.name}</h3>
        <p>天猫 · ${product.sales}</p>
        <div class="product-meta">
          <span class="label">${product.coupon}</span>
          <span class="label gold">${product.commission}</span>
        </div>
        <div class="result-price"><strong>${product.price}</strong><del>${product.oldPrice}</del></div>
      </div>
      <button class="share-btn">立即抢</button>
    </article>
  `;
}

function homeView() {
  return `
    <section class="home-hero" style="background-image: url('${bg("home_header_gradient")}')">
      <div class="status-row"><span>9:41</span><span>5G  92%</span></div>
      <div class="top-row">
        <div class="brand-name">优久久省赚商城</div>
        <button class="tag-button" data-modal="location">红包 ¥30</button>
      </div>
      <button class="search-row" data-tab-jump="coupon">
        <img class="search-icon" src="${icon("coupon_search")}" alt="" />
        <strong>搜索商品/粘贴链接查隐藏券</strong>
        <img class="mini-icon" src="${icon("paste_detect")}" alt="" />
      </button>
      <div class="tabs">
        <span class="tab-chip active">推荐</span>
        <span class="tab-chip">高佣</span>
        <span class="tab-chip">9.9</span>
        <span class="tab-chip">品牌券</span>
      </div>
    </section>

    <section class="page home-page">
      <div class="grid-card">
        ${quickItems
          .map(
            ([label, img]) =>
              `<button class="quick-item"><img class="quick-icon" src="${icon(img)}" alt="${label}" data-format="png" /><span>${label}</span></button>`,
          )
          .join("")}
      </div>

      <section class="promo">
        <div>
          <span class="promo-kicker">限时福利</span>
          <h2>大额神券每日更新</h2>
          <p>最高立减 300 元 · 分享成交赚佣金</p>
        </div>
        <span class="promo-pill">GO</span>
      </section>

      <div class="section-title">
        <div><span class="section-kicker">精选好物</span><h2>高佣推荐</h2></div>
        <button class="section-more">查看更多</button>
      </div>
      <div class="product-grid">${products.map(productCard).join("")}</div>
    </section>
  `;
}

function couponView() {
  return `
    <section class="page search-page">
      <button class="search-row plain-search" data-modal="empty">
        <img class="search-icon" src="${icon("tab_coupon_search")}" alt="" />
        <strong>搜索商品/粘贴链接查隐藏券</strong>
        <img class="mini-icon" src="${icon("link_detect")}" alt="" />
      </button>

      <div class="paste-detect-card">
        <div>
          <h2>粘贴商品链接 识别优惠券</h2>
          <p>打开淘宝/天猫/拼多多，复制链接后回来搜索</p>
        </div>
        <img src="${icon("link_detect")}" alt="" />
        <button data-modal="link">粘贴识别</button>
      </div>

      <section class="keyword-section">
        <div class="section-title compact"><h2>搜索历史</h2><button data-modal="loading">清空</button></div>
        <div class="chips">
          <span>连衣裙</span><span>耳机</span><span>空气炸锅</span><span>洗衣液</span><span>纸巾</span>
        </div>
      </section>

      <section class="hot-search">
        <div class="section-title compact"><h2>热门搜索</h2><button>换一换</button></div>
        ${["防晒霜女夏季", "蓝牙耳机无线", "涂抹面膜补水", "洗发水控油蓬松"]
          .map((item, index) => `<div class="hot-row"><span>${index + 1}</span><strong>${item}</strong><em>热度 ${56 - index * 7}.2 万</em></div>`)
          .join("")}
      </section>

      <div class="filter-row">
        <button class="active">综合</button><button>销量</button><button>佣金</button><button>券额</button><button data-modal="expired">筛选</button>
      </div>
      <div class="result-list">${searchProducts.map(searchResult).join("")}</div>
    </section>
  `;
}

function shareView() {
  const product = products[0];
  return `
    <section class="share-page">
      <header class="share-top">
        <span></span>
        <h1>素材中心</h1>
        <button>使用教程</button>
      </header>
      <section class="selected-product">
        <div class="section-title compact"><h2>已选商品</h2><button>修改 ></button></div>
        <div class="share-product">
          <img class="share-product-photo" src="${productImage(product.image)}" alt="${product.name}" />
          <div>
            <p class="product-title">${product.name}</p>
            <div class="share-product-price"><span>券后价</span><strong>${product.price}</strong></div>
            <span class="label">${product.coupon}</span>
            <span class="label gold">预估佣金 ${product.commission.replace("返", "")}</span>
          </div>
        </div>
      </section>

      <section class="share-preview-card">
        <div class="section-title compact"><h2>分享预览</h2><button>编辑文案 ></button></div>
        <div class="preview-box">
          <p>【我刚发现的好物，快来看！】这款商品券后更划算，自用省钱，分享还能赚佣金～</p>
          <div class="preview-mini"><img src="${productImage(product.image)}" alt="" /><span>来自「优久久返利」推荐</span></div>
        </div>
      </section>

      <section class="estimate-card">
        <div><span>预估收益</span><strong>¥8.6</strong><p>推广成功后佣金预计到账</p></div>
        <div><span>预估销量</span><strong>120+</strong></div>
      </section>

      <section class="share-actions">
        ${[
          ["微信群", "wechat_group"],
          ["朋友圈", "moments"],
          ["复制文案", "copywriting"],
          ["生成海报", "poster"],
          ["一键群发", "one_click_send"],
        ]
          .map(([label, img]) => `<button><img src="${icon(img)}" alt="" /><span>${label}</span></button>`)
          .join("")}
      </section>
      <button class="primary-btn share-primary" data-share>立即分享赚钱</button>
    </section>
  `;
}

function earningsView() {
  return `
    <section class="income-hero">
      <div class="status-row"><span>9:41</span><span>5G  92%</span></div>
      <p>本月预估收益(元)</p>
      <div class="income-money">¥1286.56</div>
      <button data-withdraw>收益明细 ></button>
    </section>
    <section class="income-stats">
      <div><span>可提现(元)</span><strong>¥860.30</strong><button data-withdraw>立即提现</button></div>
      <div><span>今日订单(笔)</span><strong>56</strong><button>查看订单</button></div>
      <div><span>本月订单(笔)</span><strong>326</strong><button>查看数据</button></div>
    </section>
    <section class="income-list">
      <div class="income-tabs"><span class="active">全部</span><span>已结算</span><span>待结算</span></div>
      ${[
        [products[0], "05-25 14:30", "¥8.60", "待结算"],
        [products[1], "05-25 13:20", "¥5.98", "待结算"],
      ]
        .map(
          ([product, time, money, state]) => `
          <article class="income-order">
            <img src="${productImage(product.image)}" alt="" />
            <div><h3>${product.name}</h3><p>订单号：20240526001</p><p>${time} · 付款金额 ${product.price}</p></div>
            <strong>${money}<span>${state}</span></strong>
          </article>
        `,
        )
        .join("")}
    </section>
  `;
}

function profileView() {
  return `
    <section class="profile-hero" style="background-image: url('${bg("home_header_gradient")}')">
      <div class="profile-card">
        <div class="profile-head">
          <img class="avatar" src="${icon("tab_profile")}" alt="" />
          <div class="profile-main">
            <div class="profile-title-row">
              <h1>优久久省钱达人</h1>
              <span class="level-badge">VIP2</span>
            </div>
            <p>邀请码：876543 · 高佣等级 Lv.3</p>
          </div>
          <button class="profile-action">复制</button>
        </div>
        <div class="profile-stats">
          <div><span>可提现</span><strong>¥860.30</strong></div>
          <div><span>本月预估</span><strong>¥1286.56</strong></div>
          <div><span>累计收益</span><strong>¥3260.80</strong></div>
        </div>
      </div>
    </section>
    <section class="profile-panel">
      <div class="panel-heading"><div><span>常用工具</span><h2>我的服务</h2></div><button data-modal="rules">返利规则</button></div>
      <div class="service-grid profile-service-grid">
        ${[
          ["我的订单", "orders"],
          ["我的团队", "team"],
          ["提现记录", "withdraw_record"],
          ["邀请好友", "invite_friend"],
          ["新手教程", "copywriting"],
          ["帮助中心", "rules_info"],
          ["在线客服", "customer_service"],
          ["设置", "settings"],
        ]
          .map(([label, img]) => `<button class="service-item"><img src="${icon(img)}" alt="" /><span>${label}</span></button>`)
          .join("")}
      </div>
    </section>
    <section class="profile-growth">
      <div class="growth-copy"><span>本月成长任务</span><strong>再分享 3 单升级高佣权益</strong></div>
      <div class="growth-track"><i></i></div>
      <div class="growth-meta"><span>已完成 7/10</span><button data-tab-jump="share">去分享</button></div>
    </section>
    <section class="profile-notice">
      <strong>平台保障</strong>
      <span>佣金进度透明 · 到账记录可追溯 · 在线客服随时响应</span>
    </section>
  `;
}

function detailView() {
  const product = products.find((item) => item.id === selectedProductId) || products[0];
  const commissionValue = product.commission.replace("返", "");
  const related = products.filter((item) => item.id !== product.id).slice(0, 2);
  return `
    <section class="detail-page">
      <div class="detail-top">
        <button data-back>‹</button>
        <span></span>
        <button data-share>分享</button>
      </div>
      <div class="detail-gallery">
        <img src="${productImage(product.image)}" alt="${product.name}" />
        <span>1/5</span>
      </div>
      <section class="detail-info">
        <div class="platform-badge">淘宝</div>
        <h1>${product.name}</h1>
        <p>${product.sales} · 宝贝评分 ${product.rating} · 正品保障</p>
        <div class="coupon-bar">
          <strong>${product.coupon}</strong>
          <span>限时优惠券<br />领取后下单立减</span>
          <button>立即领券</button>
        </div>
        <div class="detail-price-row">
          <div><span>券后价</span><strong>${product.price}</strong><del>${product.oldPrice}</del></div>
          <div><span>预估佣金</span><strong>${commissionValue}</strong></div>
        </div>
      </section>
      <section class="detail-benefits">
        <div class="detail-section-head"><h2>商品亮点</h2><span>${product.tag}精选</span></div>
        <div class="benefit-grid">
          ${product.highlights.map((item, index) => `<div><strong>0${index + 1}</strong><span>${item}</span></div>`).join("")}
        </div>
      </section>
      <section class="detail-service">
        <div class="detail-section-head"><h2>服务保障</h2><span>购买更放心</span></div>
        <div class="detail-service-row"><span>正品保障</span><span>极速退款</span><span>运费险</span><span>售后无忧</span></div>
      </section>
      <section class="long-detail">
        <div class="long-detail-cover">
          <img src="${detailScene(product.image)}" alt="${product.name}使用场景" />
          <div><span>${product.tag}精选</span><h2>${product.name}</h2><p>好物不只省钱，分享还能赚佣金</p></div>
        </div>
        <div class="long-detail-intro">
          <span>PRODUCT DETAILS</span>
          <h2>每一处细节，都值得认真选择</h2>
          <p>${product.highlights.join(" · ")}</p>
          <img src="${productImage(product.image)}" alt="${product.name}" />
        </div>
        ${product.highlights
          .map(
            (item, index) => `
              <div class="long-feature">
                <strong>0${index + 1}</strong>
                <div><span>核心卖点</span><h3>${item}</h3><p>精选高口碑商品，满足日常使用需求，券后入手更划算。</p></div>
              </div>`,
          )
          .join("")}
        <div class="long-detail-ending">
          <span>优久久精选</span>
          <h2>自用省钱 · 分享赚钱</h2>
          <p>领券后下单，优惠与佣金一目了然</p>
        </div>
      </section>
      <section class="detail-related">
        <div class="detail-section-head"><h2>相似推荐</h2><span>高佣优先</span></div>
        <div class="detail-related-grid">
          ${related
            .map(
              (item) => `
                <article data-detail="${item.id}">
                  <img src="${productImage(item.image)}" alt="${item.name}" />
                  <div><p>${item.name}</p><strong>${item.price}</strong><span>${item.commission}</span></div>
                </article>`,
            )
            .join("")}
        </div>
      </section>
      <div class="detail-bottom">
        <button data-tab-jump="home">首页</button><button>收藏</button>
        <button class="buy-btn">自购省 ${product.saving}</button>
        <button class="earn-btn" data-share>分享赚 ${commissionValue}</button>
      </div>
    </section>
  `;
}

function modalTemplate(type) {
  const product = products[1];
  const templates = {
    link: `
      <div class="dialog-card">
        <button class="dialog-close" data-close>×</button>
        <img class="dialog-icon" src="${icon("link_detect")}" alt="" />
        <h2>发现商品链接</h2>
        <div class="dialog-product"><img src="${productImage(product.image)}" alt="" /><div><h3>${product.name}</h3><span class="label">${product.coupon}</span><span class="label gold">预估返 ¥8.6</span></div></div>
        <button class="primary-btn">查优惠券</button><button class="secondary-btn" data-close>忽略</button>
      </div>`,
    location: `
      <div class="dialog-card compact-dialog">
        <button class="dialog-close" data-close>×</button>
        <img class="dialog-icon big" src="${icon("location_permission")}" alt="" />
        <h2>开启位置权限</h2><p>获取附近可用库存与本地优惠</p>
        <button class="primary-btn">去开启位置权限</button>
      </div>`,
    withdraw: `
      <div class="dialog-card withdraw-dialog">
        <button class="dialog-close" data-close>×</button>
        <div class="withdraw-head"><span>提现到微信零钱</span><strong>¥860.30</strong></div>
        <div class="withdraw-row"><span>到账方式</span><strong>微信零钱</strong></div>
        <div class="withdraw-row"><span>服务费</span><strong>¥0.00</strong></div>
        <div class="withdraw-row"><span>预计到账</span><strong>1-3个工作日</strong></div>
        <div class="modal-actions"><button class="secondary-btn" data-close>取消</button><button class="primary-btn">确认提现</button></div>
      </div>`,
    expired: `
      <div class="dialog-card state-card">
        <img class="dialog-icon" src="${icon("coupon_expired")}" alt="" />
        <h2>该优惠券已失效</h2><p>试试其他优惠吧</p>
        <div class="modal-actions"><button class="secondary-btn">找相似优惠</button><button class="primary-btn" data-close>重新搜索</button></div>
      </div>`,
    empty: `
      <div class="dialog-card state-card">
        <button class="dialog-close" data-close>×</button>
        <img class="dialog-icon big" src="${icon("empty_search")}" alt="" />
        <h2>没有找到可用优惠券</h2><p>换个关键词试试</p>
        <div class="chips center action-chips">
          <button data-close>换个关键词</button>
          <button data-close>粘贴商品链接</button>
          <button data-close>看今日高佣</button>
        </div>
        <button class="secondary-btn" data-close>返回上一层</button>
      </div>`,
    loading: `
      <div class="dialog-card state-card">
        <div class="skeleton-list"><i></i><i></i><i></i></div>
        <h2>加载中</h2><p>正在匹配高佣优惠</p>
      </div>`,
    rules: `
      <div class="dialog-card">
        <button class="dialog-close" data-close>×</button>
        <h2>返利规则说明</h2>
        <div class="rule-list"><p>下单后生成预估佣金</p><p>确认收货后进入待结算</p><p>平台审核后可提现</p></div>
        <button class="primary-btn" data-close>我知道了</button>
      </div>`,
  };
  return templates[type] || templates.link;
}

function showModal(type) {
  const root = document.querySelector("#modal-root");
  root.classList.remove("hidden");
  root.innerHTML = modalTemplate(type);
  root.querySelectorAll("[data-close]").forEach((el) => el.addEventListener("click", () => root.classList.add("hidden")));
  root.addEventListener("click", (event) => {
    if (event.target === root) root.classList.add("hidden");
  }, { once: true });
}

function showShareModal() {
  const product = products.find((item) => item.id === selectedProductId) || products[0];
  const root = document.querySelector("#modal-root");
  root.classList.remove("hidden");
  root.innerHTML = `
    <section class="share-modal" role="dialog" aria-modal="true" aria-label="分享确认">
      <div class="modal-title"><h2>分享赚钱</h2><button class="close" data-close>×</button></div>
      <div class="dialog-product"><img src="${productImage(product.image)}" alt="" /><div><h3>${product.name}</h3><span class="label">${product.coupon}</span><span class="label gold">预计赚 ${product.commission.replace("返", "")}</span></div></div>
      <div class="channel-grid">
        ${[
          ["微信群", "wechat_group"],
          ["朋友圈", "moments"],
          ["复制文案", "copywriting"],
          ["生成海报", "poster"],
          ["一键群发", "one_click_send"],
        ]
          .map(([label, img]) => `<button><img src="${icon(img)}" alt="" /><span>${label}</span></button>`)
          .join("")}
      </div>
      <div class="modal-summary">预计赚 ${product.commission.replace("返", "")}</div>
      <button class="primary-btn">立即分享赚钱</button>
    </section>
  `;
  root.querySelector("[data-close]").addEventListener("click", () => root.classList.add("hidden"));
  root.addEventListener("click", (event) => {
    if (event.target === root) root.classList.add("hidden");
  }, { once: true });
}

function bindActions() {
  document.querySelectorAll("[data-share]").forEach((button) => button.addEventListener("click", showShareModal));
  document.querySelectorAll("[data-withdraw]").forEach((button) => button.addEventListener("click", () => showModal("withdraw")));
  document.querySelectorAll("[data-modal]").forEach((button) => button.addEventListener("click", () => showModal(button.dataset.modal)));
  document.querySelectorAll("[data-tab-jump]").forEach((button) =>
    button.addEventListener("click", () => {
      activeTab = button.dataset.tabJump;
      activeView = "tab";
      render();
    }),
  );
  document.querySelectorAll("[data-detail]").forEach((card) =>
    card.addEventListener("click", (event) => {
      if (event.target.closest("button")) return;
      selectedProductId = card.dataset.detail;
      activeView = "detail";
      render();
    }),
  );
  document.querySelectorAll("[data-back]").forEach((button) =>
    button.addEventListener("click", () => {
      activeView = "tab";
      render();
    }),
  );
}

function render() {
  const view = document.querySelector("#view");
  const views = {
    home: homeView,
    coupon: couponView,
    share: shareView,
    earnings: earningsView,
    profile: profileView,
  };
  view.innerHTML = activeView === "detail" ? detailView() : views[activeTab]();
  renderNav();
  bindActions();
}

render();
