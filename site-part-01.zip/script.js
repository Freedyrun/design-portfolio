const page = (n, kind = "full") => `assets/pdf-${kind}/page-${String(n).padStart(2, "0")}.jpg.webp`;
const generated = (name) => `assets/generated/${name}.svg`;

const categories = {
  all: { label: "全部", intro: "可按设计类型快速浏览，重点看画面表现、页面组织和落地延展。" },
  ops: { label: "运营视觉", intro: "活动主视觉、Banner、专题页和私域海报，重点展示营销场景中的视觉转化能力。" },
  ui: { label: "UI / 网页", intro: "App、小程序和企业网页界面，重点展示信息层级、组件规范和页面一致性。" },
  brand: { label: "品牌", intro: "Logo、IP、字体和视觉延展，重点展示品牌识别与图形系统能力。" },
  aigc: { label: "AIGC", intro: "AI 视觉生成、图标探索和 3D 素材，重点展示新工具辅助下的创意产出。" },
  practice: { label: "个人练习", intro: "个人主题练习与风格实验，补充展示审美方向和画面表现力。" },
};

const projects = [
  {
    id: "project-ops",
    number: "01",
    type: "Operational Design",
    title: "朴朴运营视觉系统",
    cover: page(5),
    summary:
      "面向生鲜电商高频促销场景，围绕活动主视觉、专题页面、Banner 与私域海报建立统一的运营视觉表达。不同入口保持同一活动记忆点，同时兼顾商品信息、促销氛围与转化效率。",
    facts: ["角色：APP 视觉设计 / 运营活动视觉", "范围：港货铺、周年庆、日常 Banner、专题页、私域海报", "能力：3D 场景搭建、活动包装、跨尺寸延展"],
    points: ["用高饱和商品场景制造货架吸引力，强化促销入口的第一眼识别。", "通过统一字体层级、价格标签和色彩情绪，让不同活动保持平台感。", "把活动主视觉拆解为多尺寸物料，覆盖首页、频道页、弹窗和社群触点。"],
    pages: [4, 5, 7, 8, 11, 12, 13, 14],
    labels: ["项目封面", "港货铺主视觉", "周年庆视觉", "活动专题", "Banner 延展", "私域海报", "频道入口", "物料矩阵"],
  },
  {
    id: "project-ui",
    number: "02",
    type: "UI Design",
    title: "优久久电商平台 App",
    cover: "assets/youjiujiu-cover.png.webp",
    summary:
      "围绕电商 App 的浏览、检索、决策与个人中心场景，搭建从视觉规范到核心页面的产品界面体系。设计重点放在商品信息效率、促销氛围和移动端操作路径的平衡。",
    facts: ["角色：UI 设计 / 视觉规范搭建", "范围：字体、色彩、图标、产品架构、核心页面", "能力：信息层级、购买路径、移动端组件一致性"],
    points: ["以红橙品牌色建立强促销心智，同时用灰阶与留白保证商品信息可读。", "从产品架构出发梳理首页推荐、分类检索、购物车决策与会员中心。", "把页面矩阵作为案例核心，让招聘方能直接看到完整产品交付能力。"],
    pages: [16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 27],
    labels: ["规范封面", "字体色彩", "图标规范", "产品架构", "首页", "分类页", "购物车", "个人中心", "弹窗", "详情页", "页面矩阵"],
    prototype: {
      href: "cases/youjiujiu/index.html",
      label: "进入可交互原型",
    },
  },
  {
    id: "project-aigc",
    number: "03",
    type: "AIGC Design",
    title: "AIGC 视觉设计探索",
    cover: "assets/aigc-chapter-cover-v3.png.webp",
    concepts: [
      ...[
        ["toy-cover-v2", "潮玩系列 · AI 概念封面"],
        ["icons-v2", "企业效率工具 · 12 枚 AI 图标概念"],
        ["applications-v2", "电商展台 · AI 素材与场景概念"],
        ["game-ui", "ORBIT WORKSHOP · 背包与维修 UI 概念"],
        ["game-promo", "ORBIT WORKSHOP · 游戏宣发概念"],
        ["game-character", "ORBIT WORKSHOP · 游戏角色设定探索"],
      ].map(([name, label]) => ({ src: `assets/aigc-${name}.jpg.webp`, thumb: `assets/aigc-${name}.jpg.webp`, label, caption: `${label} / 新增 AI 视觉探索，非客户委托或可交付模型。` })),
      ...["摇滚女孩", "运动双人", "女孩与宠物", "情侣手办", "宠物手办", "魔法角色", "家庭组合"].map((name, index) => ({
        src: `assets/aigc-figure-${index + 1}.png.webp`,
        thumb: `assets/aigc-figure-${index + 1}.png.webp`,
        label: `魔力手办 · ${name}`,
        caption: `魔力手办项目 · ${name} / 用户提供的项目素材`,
      })),
      { src: "assets/aigc-packaging-layout.png.webp", thumb: "assets/aigc-packaging-layout.png.webp", label: "包装系统 · 概念展开", caption: "AFTER RAIN · 包装系统概念展示 / 瓶器、纸盒展开与手提袋，非生产刀模。" },
      { src: "assets/aigc-toy-concept.jpg.webp", thumb: "assets/aigc-toy-concept.jpg.webp", label: "潮玩手办 · AI 概念设计", caption: "潮玩手办 / AI 生成的 3D 风格概念图。探索圆润比例、透明罩材质与多配色，不代表已完成建模或生产。" },
      { src: "assets/aigc-packaging-concept.jpg.webp", thumb: "assets/aigc-packaging-concept.jpg.webp", label: "香氛包装 · AI 概念设计", caption: "AFTER RAIN / AI 包装概念。探索瓶器、礼盒与手提袋的视觉一致性，非印刷生产文件。" },
      { src: "assets/aigc-game-concept.jpg.webp", thumb: "assets/aigc-game-concept.jpg.webp", label: "轨道维修站 · AI 场景概念", caption: "轨道维修站 / AI 游戏美术概念。以等距视角探索场景与道具语言，非可运行游戏或可用 3D 模型。" },
      { src: "assets/aigc-fragrance-concept.png.webp", thumb: "assets/aigc-fragrance-concept.png.webp", label: "雨后香氛 · AI 概念设计", caption: "AFTER RAIN · 香氛品牌主视觉 / AI 概念设计，非客户委托。以雨后光影、玻璃与凝露探索产品质感。" },
      { src: "assets/aigc-sport-concept.png.webp", thumb: "assets/aigc-sport-concept.png.webp", label: "NEXT STRIDE · AI 概念设计", caption: "NEXT STRIDE · 运动产品广告 / AI 概念设计，非客户委托。以跑道曲线、对角色彩与斜向构图表达速度。" },
    ],
    summary:
      "从商业主视觉到潮玩角色、包装与游戏场景，探索 AI 在不同设计任务中的表现方式。新增系列为 AI 概念设计，结合原有图标与应用作品，呈现材质、构图和风格控制的不同方向。",
    facts: ["角色：AIGC 视觉探索 / 设计软件协同", "范围：视觉生成、B 端图标、3D 素材、应用场景", "能力：提示词控制、风格统一、后期整合与落地"],
    points: ["视觉生成：以产品特点决定光影、配色与构图，区分香氛的安静质感与运动广告的速度感。", "B 端图标：围绕功能识别组织图形，关注轮廓、透视与材质的一致性。", "3D 素材：用潮玩角色探索比例、透明树脂与哑光材质，以及配色版本。", "应用场景：将品牌语言延展至包装，将角色与道具放入完整游戏场景。"],
    pages: [47, 48, 49, 50, 51, 52, 53, 54, 55, 56],
    labels: ["AI 视觉封面", "风格探索", "角色生成", "场景生成", "插画探索", "人物视觉", "电商与角色场景", "B 端图标系统", "B 端图标应用场景", "AIGC 3D 素材"],
  },
];

const customImages = (folder, title, count, labels = []) =>
  Array.from({ length: count }, (_, index) => {
    const order = String(index + 1).padStart(2, "0");
    const label = labels[index] || `作品展示 ${order}`;
    const src = `assets/custom/${folder}/${order}.jpg.webp`;
    return { src, thumb: src, caption: `${title} · ${label}`, label };
  });

const archiveItems = [
  {
    "category": "ops",
    "title": "港货铺活动视觉",
    "images": [
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E6%B8%AF%E8%B4%A7%E9%93%BA/1%E5%B0%81%E9%9D%A2.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E6%B8%AF%E8%B4%A7%E9%93%BA/1%E5%B0%81%E9%9D%A2.png.webp",
        "label": "1封面",
        "caption": "港货铺活动视觉 · 1封面"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E6%B8%AF%E8%B4%A7%E9%93%BA/2.jpg.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E6%B8%AF%E8%B4%A7%E9%93%BA/2.jpg.webp",
        "label": "2",
        "caption": "港货铺活动视觉 · 2"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E6%B8%AF%E8%B4%A7%E9%93%BA/3.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E6%B8%AF%E8%B4%A7%E9%93%BA/3.png.webp",
        "label": "3",
        "caption": "港货铺活动视觉 · 3"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E6%B8%AF%E8%B4%A7%E9%93%BA/4.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E6%B8%AF%E8%B4%A7%E9%93%BA/4.png.webp",
        "label": "4",
        "caption": "港货铺活动视觉 · 4"
      }
    ],
    "tags": [
      "活动主视觉",
      "商品氛围",
      "专题延展"
    ]
  },
  {
    "category": "ops",
    "title": "品类日营销活动",
    "images": [
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/1.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/1.png.webp",
        "label": "1",
        "caption": "品类日营销活动 · 1"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/2.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/2.png.webp",
        "label": "2",
        "caption": "品类日营销活动 · 2"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/3.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/3.png.webp",
        "label": "3",
        "caption": "品类日营销活动 · 3"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/4.jpg.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/4.jpg.webp",
        "label": "4",
        "caption": "品类日营销活动 · 4"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/5.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/5.png.webp",
        "label": "5",
        "caption": "品类日营销活动 · 5"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/6.jpg.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/6.jpg.webp",
        "label": "6",
        "caption": "品类日营销活动 · 6"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/7.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/7.png.webp",
        "label": "7",
        "caption": "品类日营销活动 · 7"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/8.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/8.png.webp",
        "label": "8",
        "caption": "品类日营销活动 · 8"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/9.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/9.png.webp",
        "label": "9",
        "caption": "品类日营销活动 · 9"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/10.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/10.png.webp",
        "label": "10",
        "caption": "品类日营销活动 · 10"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/11.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/11.png.webp",
        "label": "11",
        "caption": "品类日营销活动 · 11"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/12.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/12.png.webp",
        "label": "12",
        "caption": "品类日营销活动 · 12"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/13.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/13.png.webp",
        "label": "13",
        "caption": "品类日营销活动 · 13"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/14.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/14.png.webp",
        "label": "14",
        "caption": "品类日营销活动 · 14"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/15.gif",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/15.gif",
        "label": "15",
        "caption": "品类日营销活动 · 15"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/16.gif",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/16.gif",
        "label": "16",
        "caption": "品类日营销活动 · 16"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/17.gif",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/17.gif",
        "label": "17",
        "caption": "品类日营销活动 · 17"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/18.gif",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/18.gif",
        "label": "18",
        "caption": "品类日营销活动 · 18"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/19.gif",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/19.gif",
        "label": "19",
        "caption": "品类日营销活动 · 19"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/20.gif",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/20.gif",
        "label": "20",
        "caption": "品类日营销活动 · 20"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/21.gif",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%93%81%E7%B1%BB%E6%97%A5/21.gif",
        "label": "21",
        "caption": "品类日营销活动 · 21"
      }
    ],
    "tags": [
      "促销视觉",
      "品类运营",
      "多尺寸延展"
    ]
  },
  {
    "category": "ops",
    "title": "夏凉百货活动",
    "images": [
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/1.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/1.png.webp",
        "label": "1",
        "caption": "夏凉百货活动 · 1"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/2.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/2.png.webp",
        "label": "2",
        "caption": "夏凉百货活动 · 2"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/3.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/3.png.webp",
        "label": "3",
        "caption": "夏凉百货活动 · 3"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/4.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/4.png.webp",
        "label": "4",
        "caption": "夏凉百货活动 · 4"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/5.gif",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/5.gif",
        "label": "5",
        "caption": "夏凉百货活动 · 5"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/6.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E5%A4%8F%E5%87%89%E7%99%BE%E8%B4%A7/6.png.webp",
        "label": "6",
        "caption": "夏凉百货活动 · 6"
      }
    ],
    "tags": [
      "季节活动",
      "品类包装",
      "动效物料"
    ]
  },
  {
    "category": "ops",
    "title": "营销海报系列",
    "images": [
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/11.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/11.png.webp",
        "label": "11",
        "caption": "营销海报系列 · 11"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/12.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/12.png.webp",
        "label": "12",
        "caption": "营销海报系列 · 12"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/13.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/13.png.webp",
        "label": "13",
        "caption": "营销海报系列 · 13"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/14.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/14.png.webp",
        "label": "14",
        "caption": "营销海报系列 · 14"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/15.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/15.png.webp",
        "label": "15",
        "caption": "营销海报系列 · 15"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/16.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/16.png.webp",
        "label": "16",
        "caption": "营销海报系列 · 16"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/17.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/17.png.webp",
        "label": "17",
        "caption": "营销海报系列 · 17"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/18.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/18.png.webp",
        "label": "18",
        "caption": "营销海报系列 · 18"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/19.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/19.png.webp",
        "label": "19",
        "caption": "营销海报系列 · 19"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/110.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/110.png.webp",
        "label": "110",
        "caption": "营销海报系列 · 110"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/111.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/111.png.webp",
        "label": "111",
        "caption": "营销海报系列 · 111"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/112.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E8%90%A5%E9%94%80%E6%B5%B7%E6%8A%A5/112.png.webp",
        "label": "112",
        "caption": "营销海报系列 · 112"
      }
    ],
    "tags": [
      "节日营销",
      "活动海报",
      "视觉节奏"
    ]
  },
  {
    "category": "ops",
    "title": "电商专题页设计",
    "images": [
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/4.11%E5%A4%96%E5%8D%96%E6%8B%9C%E6%8B%9C%EF%BC%8C%E4%BB%8A%E6%97%A5%E6%88%91%E5%BD%93%E5%8E%A8.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/4.11%E5%A4%96%E5%8D%96%E6%8B%9C%E6%8B%9C%EF%BC%8C%E4%BB%8A%E6%97%A5%E6%88%91%E5%BD%93%E5%8E%A8.png.webp",
        "label": "4.11外卖拜拜，今日我当厨",
        "caption": "电商专题页设计 · 4.11外卖拜拜，今日我当厨"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/4.21%E2%80%9C%E8%90%84%E2%80%9D%E4%BD%A0%E5%96%9C%E6%AC%A2%EF%BC%8C%E6%97%A0%E5%8F%AF%E6%8C%91%E2%80%9C%E6%8F%90%E2%80%9D.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/4.21%E2%80%9C%E8%90%84%E2%80%9D%E4%BD%A0%E5%96%9C%E6%AC%A2%EF%BC%8C%E6%97%A0%E5%8F%AF%E6%8C%91%E2%80%9C%E6%8F%90%E2%80%9D.png.webp",
        "label": "4.21“萄”你喜欢，无可挑“提”",
        "caption": "电商专题页设计 · 4.21“萄”你喜欢，无可挑“提”"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/4.28-5.01%E8%B4%9D%E7%91%9E%E7%94%9C%E5%BF%83%E7%9A%84%E7%A5%9E%E4%BB%99%E5%96%9D%E6%B3%951.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/4.28-5.01%E8%B4%9D%E7%91%9E%E7%94%9C%E5%BF%83%E7%9A%84%E7%A5%9E%E4%BB%99%E5%96%9D%E6%B3%951.png.webp",
        "label": "4.28-5.01贝瑞甜心的神仙喝法1",
        "caption": "电商专题页设计 · 4.28-5.01贝瑞甜心的神仙喝法1"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/5.1%E9%80%AE%E6%8D%95%E4%BB%A4.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/5.1%E9%80%AE%E6%8D%95%E4%BB%A4.png.webp",
        "label": "5.1逮捕令",
        "caption": "电商专题页设计 · 5.1逮捕令"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/5.9%E6%B5%B7%E5%8D%97%E5%A6%83%E5%AD%90%E7%AC%91%E8%8D%94%E6%9E%9D.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/5.9%E6%B5%B7%E5%8D%97%E5%A6%83%E5%AD%90%E7%AC%91%E8%8D%94%E6%9E%9D.png.webp",
        "label": "5.9海南妃子笑荔枝",
        "caption": "电商专题页设计 · 5.9海南妃子笑荔枝"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/6.26%E6%B7%B1%E5%9C%B3%E7%96%AF%E7%8B%82%E5%A4%A7%E5%91%A8%E6%9C%AB%E6%9C%AB%E4%B8%93%E9%A2%98%20-.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/6.26%E6%B7%B1%E5%9C%B3%E7%96%AF%E7%8B%82%E5%A4%A7%E5%91%A8%E6%9C%AB%E6%9C%AB%E4%B8%93%E9%A2%98%20-.png.webp",
        "label": "6.26深圳疯狂大周末末专题 -",
        "caption": "电商专题页设计 · 6.26深圳疯狂大周末末专题 -"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/7.7-%E4%B8%93%E9%A2%981.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/7.7-%E4%B8%93%E9%A2%981.png.webp",
        "label": "7.7-专题1",
        "caption": "电商专题页设计 · 7.7-专题1"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E8%9B%8B%E7%B3%95%E4%B8%93%E9%A2%98%E9%A1%B5_.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E8%9B%8B%E7%B3%95%E4%B8%93%E9%A2%98%E9%A1%B5_.png.webp",
        "label": "蛋糕专题页_",
        "caption": "电商专题页设计 · 蛋糕专题页_"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E5%9B%BD%E9%99%85%E8%AF%BB%E4%B9%A6%E6%97%A5.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E5%9B%BD%E9%99%85%E8%AF%BB%E4%B9%A6%E6%97%A5.png.webp",
        "label": "国际读书日",
        "caption": "电商专题页设计 · 国际读书日"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E9%87%91%E8%AA%89%E8%9B%8B%E7%B3%95.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E9%87%91%E8%AA%89%E8%9B%8B%E7%B3%95.png.webp",
        "label": "金誉蛋糕",
        "caption": "电商专题页设计 · 金誉蛋糕"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E7%B1%B3%E9%9D%A2%E7%B2%AE%E6%B2%B9.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E7%B1%B3%E9%9D%A2%E7%B2%AE%E6%B2%B9.png.webp",
        "label": "米面粮油",
        "caption": "电商专题页设计 · 米面粮油"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E6%98%8E%E4%B8%80%E4%B8%93%E9%A2%98%E9%A1%B5.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/%E4%B8%93%E9%A2%98%E9%A1%B5/%E6%98%8E%E4%B8%80%E4%B8%93%E9%A2%98%E9%A1%B5.png.webp",
        "label": "明一专题页",
        "caption": "电商专题页设计 · 明一专题页"
      }
    ],
    "tags": [
      "专题页",
      "运营转化",
      "长图排版"
    ]
  },
  {
    "category": "ops",
    "title": "站内 Banner 系统",
    "images": [
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/11.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/11.png.webp",
        "label": "11",
        "caption": "站内 Banner 系统 · 11"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/12.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/12.png.webp",
        "label": "12",
        "caption": "站内 Banner 系统 · 12"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/13.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/13.png.webp",
        "label": "13",
        "caption": "站内 Banner 系统 · 13"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/14.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/14.png.webp",
        "label": "14",
        "caption": "站内 Banner 系统 · 14"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/15.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/15.png.webp",
        "label": "15",
        "caption": "站内 Banner 系统 · 15"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/16.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/16.png.webp",
        "label": "16",
        "caption": "站内 Banner 系统 · 16"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/17.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/17.png.webp",
        "label": "17",
        "caption": "站内 Banner 系统 · 17"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/18.jpg.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/18.jpg.webp",
        "label": "18",
        "caption": "站内 Banner 系统 · 18"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/19.jpg.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/19.jpg.webp",
        "label": "19",
        "caption": "站内 Banner 系统 · 19"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/110.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/110.png.webp",
        "label": "110",
        "caption": "站内 Banner 系统 · 110"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/111.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/111.png.webp",
        "label": "111",
        "caption": "站内 Banner 系统 · 111"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/112.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/112.png.webp",
        "label": "112",
        "caption": "站内 Banner 系统 · 112"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/113.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/113.png.webp",
        "label": "113",
        "caption": "站内 Banner 系统 · 113"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/114.png.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/114.png.webp",
        "label": "114",
        "caption": "站内 Banner 系统 · 114"
      },
      {
        "src": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/115.jpg.webp",
        "thumb": "assets/library-import/%E8%90%A5%E9%94%80%E8%AE%BE%E8%AE%A1/banner/115.jpg.webp",
        "label": "115",
        "caption": "站内 Banner 系统 · 115"
      }
    ],
    "tags": [
      "Banner",
      "首页入口",
      "商品信息"
    ]
  },
  {
    "category": "ui",
    "title": "面板界面设计",
    "images": [
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E9%9D%A2%E6%9D%BF%E7%95%8C%E9%9D%A2/1.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E9%9D%A2%E6%9D%BF%E7%95%8C%E9%9D%A2/1.png.webp",
        "label": "1",
        "caption": "面板界面设计 · 1"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E9%9D%A2%E6%9D%BF%E7%95%8C%E9%9D%A2/2.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E9%9D%A2%E6%9D%BF%E7%95%8C%E9%9D%A2/2.png.webp",
        "label": "2",
        "caption": "面板界面设计 · 2"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E9%9D%A2%E6%9D%BF%E7%95%8C%E9%9D%A2/3.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E9%9D%A2%E6%9D%BF%E7%95%8C%E9%9D%A2/3.png.webp",
        "label": "3",
        "caption": "面板界面设计 · 3"
      }
    ],
    "tags": []
  },
  {
    "category": "ui",
    "title": "优久久电商 App",
    "images": [
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/156.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/156.png.webp",
        "label": "156",
        "caption": "优久久电商 App · 156"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/157.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/157.png.webp",
        "label": "157",
        "caption": "优久久电商 App · 157"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/158.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/158.png.webp",
        "label": "158",
        "caption": "优久久电商 App · 158"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/159.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/159.png.webp",
        "label": "159",
        "caption": "优久久电商 App · 159"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/160.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/160.png.webp",
        "label": "160",
        "caption": "优久久电商 App · 160"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/161.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/161.png.webp",
        "label": "161",
        "caption": "优久久电商 App · 161"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/162.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/162.png.webp",
        "label": "162",
        "caption": "优久久电商 App · 162"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/163.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/163.png.webp",
        "label": "163",
        "caption": "优久久电商 App · 163"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/164.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/164.png.webp",
        "label": "164",
        "caption": "优久久电商 App · 164"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/165.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E4%BC%98%E4%B9%85%E4%B9%85/165.png.webp",
        "label": "165",
        "caption": "优久久电商 App · 165"
      }
    ],
    "tags": [
      "产品界面",
      "视觉规范",
      "电商链路"
    ],
    "cover": "assets/custom/ui/youjiujiu/cover.png.webp"
  },
  {
    "category": "ui",
    "title": "蒸见康小程序",
    "images": [
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E8%92%B8%E8%A7%81%E5%BA%B7/156.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E8%92%B8%E8%A7%81%E5%BA%B7/156.png.webp",
        "label": "156",
        "caption": "蒸见康小程序 · 156"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E8%92%B8%E8%A7%81%E5%BA%B7/157.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E8%92%B8%E8%A7%81%E5%BA%B7/157.png.webp",
        "label": "157",
        "caption": "蒸见康小程序 · 157"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E8%92%B8%E8%A7%81%E5%BA%B7/158.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E8%92%B8%E8%A7%81%E5%BA%B7/158.png.webp",
        "label": "158",
        "caption": "蒸见康小程序 · 158"
      },
      {
        "src": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E8%92%B8%E8%A7%81%E5%BA%B7/159.png.webp",
        "thumb": "assets/library-import/UI%E8%AE%BE%E8%AE%A1/%E7%A7%BB%E5%8A%A8%E7%AB%AF/%E8%92%B8%E8%A7%81%E5%BA%B7/159.png.webp",
        "label": "159",
        "caption": "蒸见康小程序 · 159"
      }
    ],
    "tags": [
      "小程序",
      "餐饮体验",
      "页面层级"
    ],
    "cover": "assets/custom/ui/zhengjiankang/cover.png.webp"
  },
  {
    "category": "ui",
    "title": "中瑞集团网页",
    "cover": "assets/custom/ui/zhongrui-web-new/cover.png.webp",
    "images": [
      {
        "src": "assets/custom/ui/zhongrui-web-new/01-首页.png.webp",
        "thumb": "assets/custom/ui/zhongrui-web-new/01-首页.png.webp",
        "caption": "中瑞集团网页 · 首页",
        "label": "首页"
      },
      {
        "src": "assets/custom/ui/zhongrui-web-new/02-集团简介.png.webp",
        "thumb": "assets/custom/ui/zhongrui-web-new/02-集团简介.png.webp",
        "caption": "中瑞集团网页 · 集团简介",
        "label": "集团简介"
      },
      {
        "src": "assets/custom/ui/zhongrui-web-new/03-产业版图.png.webp",
        "thumb": "assets/custom/ui/zhongrui-web-new/03-产业版图.png.webp",
        "caption": "中瑞集团网页 · 产业版图",
        "label": "产业版图"
      },
      {
        "src": "assets/custom/ui/zhongrui-web-new/04-公司资讯.png.webp",
        "thumb": "assets/custom/ui/zhongrui-web-new/04-公司资讯.png.webp",
        "caption": "中瑞集团网页 · 公司资讯",
        "label": "公司资讯"
      },
      {
        "src": "assets/custom/ui/zhongrui-web-new/05-加入我们.png.webp",
        "thumb": "assets/custom/ui/zhongrui-web-new/05-加入我们.png.webp",
        "caption": "中瑞集团网页 · 加入我们",
        "label": "加入我们"
      },
      {
        "src": "assets/custom/ui/zhongrui-web-new/06-联系我们.png.webp",
        "thumb": "assets/custom/ui/zhongrui-web-new/06-联系我们.png.webp",
        "caption": "中瑞集团网页 · 联系我们",
        "label": "联系我们"
      }
    ],
    "tags": [
      "企业官网",
      "信息架构",
      "品牌呈现"
    ]
  },
  {
    "category": "ui",
    "title": "创特科技网页",
    "cover": "assets/custom/ui/chuangte-web-new/cover.png.webp",
    "images": [
      {
        "src": "assets/custom/ui/chuangte-web-new/01-首页.png.webp",
        "thumb": "assets/custom/ui/chuangte-web-new/01-首页.png.webp",
        "caption": "创特科技网页 · 首页",
        "label": "首页"
      },
      {
        "src": "assets/custom/ui/chuangte-web-new/02-走进创特.png.webp",
        "thumb": "assets/custom/ui/chuangte-web-new/02-走进创特.png.webp",
        "caption": "创特科技网页 · 走进创特",
        "label": "走进创特"
      },
      {
        "src": "assets/custom/ui/chuangte-web-new/03-产品中心.png.webp",
        "thumb": "assets/custom/ui/chuangte-web-new/03-产品中心.png.webp",
        "caption": "创特科技网页 · 产品中心",
        "label": "产品中心"
      },
      {
        "src": "assets/custom/ui/chuangte-web-new/04-解决方案.png.webp",
        "thumb": "assets/custom/ui/chuangte-web-new/04-解决方案.png.webp",
        "caption": "创特科技网页 · 解决方案",
        "label": "解决方案"
      },
      {
        "src": "assets/custom/ui/chuangte-web-new/05-工程案例.png.webp",
        "thumb": "assets/custom/ui/chuangte-web-new/05-工程案例.png.webp",
        "caption": "创特科技网页 · 工程案例",
        "label": "工程案例"
      },
      {
        "src": "assets/custom/ui/chuangte-web-new/06-联系我们.png.webp",
        "thumb": "assets/custom/ui/chuangte-web-new/06-联系我们.png.webp",
        "caption": "创特科技网页 · 联系我们",
        "label": "联系我们"
      }
    ],
    "tags": [
      "科技官网",
      "响应式界面",
      "品牌表达"
    ]
  },
  {
    "category": "brand",
    "title": "表情包 · 瓷天下",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E7%93%B7%E5%A4%A9%E4%B8%8B/iPhone%2012-12%20Pro%20%E2%80%93%2025.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E7%93%B7%E5%A4%A9%E4%B8%8B/iPhone%2012-12%20Pro%20%E2%80%93%2025.png.webp",
        "label": "iPhone 12-12 Pro – 25",
        "caption": "表情包 · 瓷天下 · iPhone 12-12 Pro – 25"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "表情包 · 帝小虎 · 2d",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/1w7lq-lzbqg.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/1w7lq-lzbqg.gif",
        "label": "1w7lq-lzbqg",
        "caption": "表情包 · 帝小虎 · 2d · 1w7lq-lzbqg"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/3a3779b9-46a1-4b97-8318-a5ab57dea9b2.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/3a3779b9-46a1-4b97-8318-a5ab57dea9b2.gif",
        "label": "3a3779b9-46a1-4b97-8318-a5ab57dea9b2",
        "caption": "表情包 · 帝小虎 · 2d · 3a3779b9-46a1-4b97-8318-a5ab57dea9b2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/3d53ea70-4581-45e1-b395-6c8a3627956b.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/3d53ea70-4581-45e1-b395-6c8a3627956b.gif",
        "label": "3d53ea70-4581-45e1-b395-6c8a3627956b",
        "caption": "表情包 · 帝小虎 · 2d · 3d53ea70-4581-45e1-b395-6c8a3627956b"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/4db1cf33-c016-4c61-b31d-cb1ccac1f139.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/4db1cf33-c016-4c61-b31d-cb1ccac1f139.gif",
        "label": "4db1cf33-c016-4c61-b31d-cb1ccac1f139",
        "caption": "表情包 · 帝小虎 · 2d · 4db1cf33-c016-4c61-b31d-cb1ccac1f139"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/6febbd53-cc87-40a2-9c23-067c8db079af.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/6febbd53-cc87-40a2-9c23-067c8db079af.gif",
        "label": "6febbd53-cc87-40a2-9c23-067c8db079af",
        "caption": "表情包 · 帝小虎 · 2d · 6febbd53-cc87-40a2-9c23-067c8db079af"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/8bbdfcca-1f3e-4391-bd9c-bb374e74d36e.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/8bbdfcca-1f3e-4391-bd9c-bb374e74d36e.gif",
        "label": "8bbdfcca-1f3e-4391-bd9c-bb374e74d36e",
        "caption": "表情包 · 帝小虎 · 2d · 8bbdfcca-1f3e-4391-bd9c-bb374e74d36e"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/9b5a7cc2-5e88-4cb0-89dd-b9d796cfa9c2.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/9b5a7cc2-5e88-4cb0-89dd-b9d796cfa9c2.gif",
        "label": "9b5a7cc2-5e88-4cb0-89dd-b9d796cfa9c2",
        "caption": "表情包 · 帝小虎 · 2d · 9b5a7cc2-5e88-4cb0-89dd-b9d796cfa9c2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/09c3da67-023f-431d-b0f6-f64e0613e829.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/09c3da67-023f-431d-b0f6-f64e0613e829.gif",
        "label": "09c3da67-023f-431d-b0f6-f64e0613e829",
        "caption": "表情包 · 帝小虎 · 2d · 09c3da67-023f-431d-b0f6-f64e0613e829"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/32fb29ed-d605-46be-b298-80bc31d97544.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/32fb29ed-d605-46be-b298-80bc31d97544.gif",
        "label": "32fb29ed-d605-46be-b298-80bc31d97544",
        "caption": "表情包 · 帝小虎 · 2d · 32fb29ed-d605-46be-b298-80bc31d97544"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/96f08111-064c-412a-8aeb-b80056a15444.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/96f08111-064c-412a-8aeb-b80056a15444.gif",
        "label": "96f08111-064c-412a-8aeb-b80056a15444",
        "caption": "表情包 · 帝小虎 · 2d · 96f08111-064c-412a-8aeb-b80056a15444"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/325b3bc9-5529-4d25-88e5-e61c8793f8cd.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/325b3bc9-5529-4d25-88e5-e61c8793f8cd.gif",
        "label": "325b3bc9-5529-4d25-88e5-e61c8793f8cd",
        "caption": "表情包 · 帝小虎 · 2d · 325b3bc9-5529-4d25-88e5-e61c8793f8cd"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/1505e73f-e476-481d-9720-f97635ade24a.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/1505e73f-e476-481d-9720-f97635ade24a.gif",
        "label": "1505e73f-e476-481d-9720-f97635ade24a",
        "caption": "表情包 · 帝小虎 · 2d · 1505e73f-e476-481d-9720-f97635ade24a"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/3198d9f0-2ab1-4d67-8477-35d00595b5d1.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/3198d9f0-2ab1-4d67-8477-35d00595b5d1.gif",
        "label": "3198d9f0-2ab1-4d67-8477-35d00595b5d1",
        "caption": "表情包 · 帝小虎 · 2d · 3198d9f0-2ab1-4d67-8477-35d00595b5d1"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/5519f162-a7ee-47f4-b89c-919078c20306.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/5519f162-a7ee-47f4-b89c-919078c20306.gif",
        "label": "5519f162-a7ee-47f4-b89c-919078c20306",
        "caption": "表情包 · 帝小虎 · 2d · 5519f162-a7ee-47f4-b89c-919078c20306"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/385816f7-abe9-4db0-aa5c-3892a51181df.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/385816f7-abe9-4db0-aa5c-3892a51181df.gif",
        "label": "385816f7-abe9-4db0-aa5c-3892a51181df",
        "caption": "表情包 · 帝小虎 · 2d · 385816f7-abe9-4db0-aa5c-3892a51181df"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/c495600a-ae39-4b34-a717-87854ee56908.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/c495600a-ae39-4b34-a717-87854ee56908.gif",
        "label": "c495600a-ae39-4b34-a717-87854ee56908",
        "caption": "表情包 · 帝小虎 · 2d · c495600a-ae39-4b34-a717-87854ee56908"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/cf1d1cbc-06ac-43bd-80ec-f022f3b551cc.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/cf1d1cbc-06ac-43bd-80ec-f022f3b551cc.gif",
        "label": "cf1d1cbc-06ac-43bd-80ec-f022f3b551cc",
        "caption": "表情包 · 帝小虎 · 2d · cf1d1cbc-06ac-43bd-80ec-f022f3b551cc"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/e47898fe-afcb-401f-8a33-7ab3055f03cc.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/e47898fe-afcb-401f-8a33-7ab3055f03cc.gif",
        "label": "e47898fe-afcb-401f-8a33-7ab3055f03cc",
        "caption": "表情包 · 帝小虎 · 2d · e47898fe-afcb-401f-8a33-7ab3055f03cc"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/f56e4d5e-ef2f-46c0-afa8-03386b113a1f.gif",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/2d/f56e4d5e-ef2f-46c0-afa8-03386b113a1f.gif",
        "label": "f56e4d5e-ef2f-46c0-afa8-03386b113a1f",
        "caption": "表情包 · 帝小虎 · 2d · f56e4d5e-ef2f-46c0-afa8-03386b113a1f"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "表情包 · 帝小虎 · 3d",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%A5%A5%E5%88%A9%E7%BB%991.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%A5%A5%E5%88%A9%E7%BB%991.png.webp",
        "label": "奥利给1",
        "caption": "表情包 · 帝小虎 · 3d · 奥利给1"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%A5%A5%E5%88%A9%E7%BB%992.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%A5%A5%E5%88%A9%E7%BB%992.png.webp",
        "label": "奥利给2",
        "caption": "表情包 · 帝小虎 · 3d · 奥利给2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%A5%A5%E5%88%A9%E7%BB%993.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%A5%A5%E5%88%A9%E7%BB%993.png.webp",
        "label": "奥利给3",
        "caption": "表情包 · 帝小虎 · 3d · 奥利给3"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E6%A3%92.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E6%A3%92.png.webp",
        "label": "棒",
        "caption": "表情包 · 帝小虎 · 3d · 棒"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E6%89%93%E6%89%B0%E4%BA%86.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E6%89%93%E6%89%B0%E4%BA%86.png.webp",
        "label": "打扰了",
        "caption": "表情包 · 帝小虎 · 3d · 打扰了"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E6%89%93%E6%89%B0%E4%BA%862.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E6%89%93%E6%89%B0%E4%BA%862.png.webp",
        "label": "打扰了2",
        "caption": "表情包 · 帝小虎 · 3d · 打扰了2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%93%88%E5%93%88%E5%93%88.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%93%88%E5%93%88%E5%93%88.png.webp",
        "label": "哈哈哈",
        "caption": "表情包 · 帝小虎 · 3d · 哈哈哈"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%97%A8%E8%B5%B7%E6%9D%A5.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%97%A8%E8%B5%B7%E6%9D%A5.png.webp",
        "label": "嗨起来",
        "caption": "表情包 · 帝小虎 · 3d · 嗨起来"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%A5%BD%E5%98%9E2.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%A5%BD%E5%98%9E2.png.webp",
        "label": "好嘞2",
        "caption": "表情包 · 帝小虎 · 3d · 好嘞2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%8A%A01.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%8A%A01.png.webp",
        "label": "加1",
        "caption": "表情包 · 帝小虎 · 3d · 加1"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%BA%A0%E7%BB%93.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%BA%A0%E7%BB%93.png.webp",
        "label": "纠结",
        "caption": "表情包 · 帝小虎 · 3d · 纠结"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%BA%A0%E7%BB%932.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%BA%A0%E7%BB%932.png.webp",
        "label": "纠结2",
        "caption": "表情包 · 帝小虎 · 3d · 纠结2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%BA%A0%E7%BB%933.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%BA%A0%E7%BB%933.png.webp",
        "label": "纠结3",
        "caption": "表情包 · 帝小虎 · 3d · 纠结3"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%8F%AF%E4%BB%A5.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%8F%AF%E4%BB%A5.png.webp",
        "label": "可以",
        "caption": "表情包 · 帝小虎 · 3d · 可以"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%9B%B0.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%9B%B0.png.webp",
        "label": "困",
        "caption": "表情包 · 帝小虎 · 3d · 困"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%B4%AF%E4%BA%86.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%B4%AF%E4%BA%86.png.webp",
        "label": "累了",
        "caption": "表情包 · 帝小虎 · 3d · 累了"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%B4%AF%E4%BA%862.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E7%B4%AF%E4%BA%862.png.webp",
        "label": "累了2",
        "caption": "表情包 · 帝小虎 · 3d · 累了2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%BF%99.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%BF%99.png.webp",
        "label": "忙",
        "caption": "表情包 · 帝小虎 · 3d · 忙"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%93%A6.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%93%A6.png.webp",
        "label": "哦",
        "caption": "表情包 · 帝小虎 · 3d · 哦"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E4%BB%80%E4%B9%88%E9%AC%BC.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E4%BB%80%E4%B9%88%E9%AC%BC.png.webp",
        "label": "什么鬼",
        "caption": "表情包 · 帝小虎 · 3d · 什么鬼"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E4%BB%80%E4%B9%88%E9%AC%BC2.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E4%BB%80%E4%B9%88%E9%AC%BC2.png.webp",
        "label": "什么鬼2",
        "caption": "表情包 · 帝小虎 · 3d · 什么鬼2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%93%87%E5%93%A6.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%93%87%E5%93%A6.png.webp",
        "label": "哇哦",
        "caption": "表情包 · 帝小虎 · 3d · 哇哦"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%B7%B2%E8%AF%BB%E4%B8%8D%E5%9B%9E.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%B7%B2%E8%AF%BB%E4%B8%8D%E5%9B%9E.png.webp",
        "label": "已读不回",
        "caption": "表情包 · 帝小虎 · 3d · 已读不回"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%B7%B2%E8%AF%BB%E4%B8%8D%E5%9B%9E2.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%B7%B2%E8%AF%BB%E4%B8%8D%E5%9B%9E2.png.webp",
        "label": "已读不回2",
        "caption": "表情包 · 帝小虎 · 3d · 已读不回2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%86%8D%E8%A7%81.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%86%8D%E8%A7%81.png.webp",
        "label": "再见",
        "caption": "表情包 · 帝小虎 · 3d · 再见"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%86%8D%E8%A7%812.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/%E5%86%8D%E8%A7%812.png.webp",
        "label": "再见2",
        "caption": "表情包 · 帝小虎 · 3d · 再见2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/ENEN%20.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/ENEN%20.png.webp",
        "label": "ENEN ",
        "caption": "表情包 · 帝小虎 · 3d · ENEN "
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/HI.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/HI.png.webp",
        "label": "HI",
        "caption": "表情包 · 帝小虎 · 3d · HI"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/HI2.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%B8%9D%E5%B0%8F%E8%99%8E/3d/HI2.png.webp",
        "label": "HI2",
        "caption": "表情包 · 帝小虎 · 3d · HI2"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "表情包 · 电灯熊",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E7%94%B5%E7%81%AF%E7%86%8A/iPhone%2012-12%20Pro%20%E2%80%93%2026.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E7%94%B5%E7%81%AF%E7%86%8A/iPhone%2012-12%20Pro%20%E2%80%93%2026.png.webp",
        "label": "iPhone 12-12 Pro – 26",
        "caption": "表情包 · 电灯熊 · iPhone 12-12 Pro – 26"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "表情包 · 夜游神",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E4%B8%8D%E7%94%9F%E6%B0%94.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E4%B8%8D%E7%94%9F%E6%B0%94.jpg.webp",
        "label": "√不生气",
        "caption": "表情包 · 夜游神 · √不生气"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E6%8A%96%E8%82%A9%E8%88%9E.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E6%8A%96%E8%82%A9%E8%88%9E.jpg.webp",
        "label": "√抖肩舞",
        "caption": "表情包 · 夜游神 · √抖肩舞"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E9%A3%9E.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E9%A3%9E.jpg.webp",
        "label": "√飞",
        "caption": "表情包 · 夜游神 · √飞"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E8%8A%B1%E7%97%B4.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E8%8A%B1%E7%97%B4.jpg.webp",
        "label": "√花痴",
        "caption": "表情包 · 夜游神 · √花痴"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E6%BF%80%E5%85%89.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E6%BF%80%E5%85%89.jpg.webp",
        "label": "√激光",
        "caption": "表情包 · 夜游神 · √激光"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E5%93%AD%E6%B3%A3.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E5%93%AD%E6%B3%A3.jpg.webp",
        "label": "√哭泣",
        "caption": "表情包 · 夜游神 · √哭泣"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E4%BD%A0%E7%9E%85%E5%95%A5.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E4%BD%A0%E7%9E%85%E5%95%A5.jpg.webp",
        "label": "√你瞅啥",
        "caption": "表情包 · 夜游神 · √你瞅啥"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E7%A9%B7.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E7%A9%B7.jpg.webp",
        "label": "√穷",
        "caption": "表情包 · 夜游神 · √穷"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E5%A6%96%E6%80%AA%E5%93%AA%E9%87%8C%E8%B7%91.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E2%88%9A%E5%A6%96%E6%80%AA%E5%93%AA%E9%87%8C%E8%B7%91.jpg.webp",
        "label": "√妖怪哪里跑",
        "caption": "表情包 · 夜游神 · √妖怪哪里跑"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E6%9A%97%E4%B8%AD%E8%A7%82%E5%AF%9F.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E6%9A%97%E4%B8%AD%E8%A7%82%E5%AF%9F.jpg.webp",
        "label": "暗中观察",
        "caption": "表情包 · 夜游神 · 暗中观察"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E5%90%83%E7%93%9C.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E5%90%83%E7%93%9C.jpg.webp",
        "label": "吃瓜",
        "caption": "表情包 · 夜游神 · 吃瓜"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E5%90%88%E6%88%90-1_122.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E5%90%88%E6%88%90-1_122.jpg.webp",
        "label": "合成-1_122",
        "caption": "表情包 · 夜游神 · 合成-1_122"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E6%80%9D%E8%80%83.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E6%80%9D%E8%80%83.jpg.webp",
        "label": "思考",
        "caption": "表情包 · 夜游神 · 思考"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E8%80%B6.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E8%80%B6.jpg.webp",
        "label": "耶",
        "caption": "表情包 · 夜游神 · 耶"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E4%B8%AD%E7%AE%AD.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/%E4%B8%AD%E7%AE%AD.jpg.webp",
        "label": "中箭",
        "caption": "表情包 · 夜游神 · 中箭"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/jiayou-.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E8%A1%A8%E6%83%85%E5%8C%85/%E5%A4%9C%E6%B8%B8%E7%A5%9E/jiayou-.jpg.webp",
        "label": "jiayou-",
        "caption": "表情包 · 夜游神 · jiayou-"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "企业宣传海报",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E7%A8%8B%E5%BA%8F%E5%91%98AI%E7%BC%96%E7%A8%8B%E5%A4%A7%E8%B5%9B%E6%B4%BB%E5%8A%A8%E9%95%BF%E5%9B%BE.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E7%A8%8B%E5%BA%8F%E5%91%98AI%E7%BC%96%E7%A8%8B%E5%A4%A7%E8%B5%9B%E6%B4%BB%E5%8A%A8%E9%95%BF%E5%9B%BE.jpg.webp",
        "label": "程序员AI编程大赛活动长图",
        "caption": "企业宣传海报 · 程序员AI编程大赛活动长图"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E5%B8%9D%E8%A7%869%E5%91%A8%E5%B9%B4%E6%B5%B7%E6%8A%A5.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E5%B8%9D%E8%A7%869%E5%91%A8%E5%B9%B4%E6%B5%B7%E6%8A%A5.png.webp",
        "label": "帝视9周年海报",
        "caption": "企业宣传海报 · 帝视9周年海报"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E7%AB%AF%E5%8D%88%E8%8A%82%E6%B5%B7%E6%8A%A5.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E7%AB%AF%E5%8D%88%E8%8A%82%E6%B5%B7%E6%8A%A5.png.webp",
        "label": "端午节海报",
        "caption": "企业宣传海报 · 端午节海报"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E7%AB%8B%E5%B1%8F3.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E7%AB%8B%E5%B1%8F3.jpg.webp",
        "label": "立屏3",
        "caption": "企业宣传海报 · 立屏3"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E4%BA%94%E4%B8%80%E6%B5%B7%E6%8A%A5.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E4%BA%94%E4%B8%80%E6%B5%B7%E6%8A%A5.png.webp",
        "label": "五一海报",
        "caption": "企业宣传海报 · 五一海报"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E8%A5%BF%E9%80%92%E6%B5%B7%E6%8A%A5.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E8%A5%BF%E9%80%92%E6%B5%B7%E6%8A%A5.jpg.webp",
        "label": "西递海报",
        "caption": "企业宣传海报 · 西递海报"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E4%B8%AD%E7%A7%8B%E5%9B%A2%E5%BB%BA%E6%B5%B7%E6%8A%A5.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/%E4%B8%AD%E7%A7%8B%E5%9B%A2%E5%BB%BA%E6%B5%B7%E6%8A%A5.png.webp",
        "label": "中秋团建海报",
        "caption": "企业宣传海报 · 中秋团建海报"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_57_36.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_57_36.png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_57_36",
        "caption": "企业宣传海报 · ChatGPT Image 2026年9月11日 21_57_36"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2022_06_06.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E4%BC%81%E4%B8%9A%E5%AE%A3%E4%BC%A0%E6%B5%B7%E6%8A%A5/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2022_06_06.png.webp",
        "label": "ChatGPT Image 2026年9月11日 22_06_06",
        "caption": "企业宣传海报 · ChatGPT Image 2026年9月11日 22_06_06"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "手册 · 也有神书",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/%E4%B9%9F%E6%9C%89%E7%A5%9E%E4%B9%A6/41ab36cbf6946b217d300431cc52cc4.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/%E4%B9%9F%E6%9C%89%E7%A5%9E%E4%B9%A6/41ab36cbf6946b217d300431cc52cc4.png.webp",
        "label": "41ab36cbf6946b217d300431cc52cc4",
        "caption": "手册 · 也有神书 · 41ab36cbf6946b217d300431cc52cc4"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/%E4%B9%9F%E6%9C%89%E7%A5%9E%E4%B9%A6/116613.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/%E4%B9%9F%E6%9C%89%E7%A5%9E%E4%B9%A6/116613.png.webp",
        "label": "116613",
        "caption": "手册 · 也有神书 · 116613"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/%E4%B9%9F%E6%9C%89%E7%A5%9E%E4%B9%A6/d0d2ba7175e1998b94c774b2731e4a9.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/%E4%B9%9F%E6%9C%89%E7%A5%9E%E4%B9%A6/d0d2ba7175e1998b94c774b2731e4a9.png.webp",
        "label": "d0d2ba7175e1998b94c774b2731e4a9",
        "caption": "手册 · 也有神书 · d0d2ba7175e1998b94c774b2731e4a9"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "手册 · vi手册",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/vi%E6%89%8B%E5%86%8C/iPhone%2012-12%20Pro%20%E2%80%93%2027.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/vi%E6%89%8B%E5%86%8C/iPhone%2012-12%20Pro%20%E2%80%93%2027.png.webp",
        "label": "iPhone 12-12 Pro – 27",
        "caption": "手册 · vi手册 · iPhone 12-12 Pro – 27"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/vi%E6%89%8B%E5%86%8C/iPhone%2012-12%20Pro%20%E2%80%93%2028.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C/vi%E6%89%8B%E5%86%8C/iPhone%2012-12%20Pro%20%E2%80%93%2028.png.webp",
        "label": "iPhone 12-12 Pro – 28",
        "caption": "手册 · vi手册 · iPhone 12-12 Pro – 28"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "手册导出图",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/1-2.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/1-2.png.webp",
        "label": "1-2",
        "caption": "手册导出图 · 1-2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/3-4.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/3-4.png.webp",
        "label": "3-4",
        "caption": "手册导出图 · 3-4"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/5-6.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/5-6.png.webp",
        "label": "5-6",
        "caption": "手册导出图 · 5-6"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/7-8.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/7-8.png.webp",
        "label": "7-8",
        "caption": "手册导出图 · 7-8"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/9-10.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/9-10.png.webp",
        "label": "9-10",
        "caption": "手册导出图 · 9-10"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/11-12.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/11-12.png.webp",
        "label": "11-12",
        "caption": "手册导出图 · 11-12"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/13-14.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%89%8B%E5%86%8C%E5%AF%BC%E5%87%BA%E5%9B%BE/13-14.png.webp",
        "label": "13-14",
        "caption": "手册导出图 · 13-14"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "文创 · 包装",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/1464161.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/1464161.png.webp",
        "label": "1464161",
        "caption": "文创 · 包装 · 1464161"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/2626161.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/2626161.png.webp",
        "label": "2626161",
        "caption": "文创 · 包装 · 2626161"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/211521515.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/211521515.png.webp",
        "label": "211521515",
        "caption": "文创 · 包装 · 211521515"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/%E9%BB%91%E8%89%B2.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/%E9%BB%91%E8%89%B2.png.webp",
        "label": "黑色",
        "caption": "文创 · 包装 · 黑色"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/%E6%A6%B4%E8%8E%B2.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/%E6%A6%B4%E8%8E%B2.png.webp",
        "label": "榴莲",
        "caption": "文创 · 包装 · 榴莲"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/%E6%8E%92%E9%AA%A8%E9%B8%A1%E7%88%AA.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/%E6%8E%92%E9%AA%A8%E9%B8%A1%E7%88%AA.jpg.webp",
        "label": "排骨鸡爪",
        "caption": "文创 · 包装 · 排骨鸡爪"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/%E8%99%BE%E9%A5%BA%E7%83%A7%E5%8D%96.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/%E8%99%BE%E9%A5%BA%E7%83%A7%E5%8D%96.jpg.webp",
        "label": "虾饺烧卖",
        "caption": "文创 · 包装 · 虾饺烧卖"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/Untitled.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/Untitled.jpg.webp",
        "label": "Untitled",
        "caption": "文创 · 包装 · Untitled"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/Untitled.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%8C%85%E8%A3%85/Untitled.png.webp",
        "label": "Untitled",
        "caption": "文创 · 包装 · Untitled"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "文创 · 冰箱贴",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E9%BC%93%E6%B5%AA%E5%B1%BF%E5%86%B0%E7%AE%B1%E8%B4%B4.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E9%BC%93%E6%B5%AA%E5%B1%BF%E5%86%B0%E7%AE%B1%E8%B4%B4.png.webp",
        "label": "鼓浪屿冰箱贴",
        "caption": "文创 · 冰箱贴 · 鼓浪屿冰箱贴"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E9%87%91%E5%B1%9Ebxt%E6%95%88%E6%9E%9C%E5%9B%BE.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E9%87%91%E5%B1%9Ebxt%E6%95%88%E6%9E%9C%E5%9B%BE.png.webp",
        "label": "金属bxt效果图",
        "caption": "文创 · 冰箱贴 · 金属bxt效果图"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E8%B7%AF%E8%BE%B9%E8%B4%B5%E9%98%B3%E5%86%B0%E7%AE%B1%E8%B4%B4.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E8%B7%AF%E8%BE%B9%E8%B4%B5%E9%98%B3%E5%86%B0%E7%AE%B1%E8%B4%B4.png.webp",
        "label": "路边贵阳冰箱贴",
        "caption": "文创 · 冰箱贴 · 路边贵阳冰箱贴"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E7%89%8C%E5%9D%8A.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E7%89%8C%E5%9D%8A.png.webp",
        "label": "牌坊",
        "caption": "文创 · 冰箱贴 · 牌坊"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E6%98%9F%E5%AE%89.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E6%98%9F%E5%AE%89.png.webp",
        "label": "星安",
        "caption": "文创 · 冰箱贴 · 星安"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E5%BC%A0%E5%90%9B.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%86%B0%E7%AE%B1%E8%B4%B4/%E5%BC%A0%E5%90%9B.png.webp",
        "label": "张君",
        "caption": "文创 · 冰箱贴 · 张君"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "文创 · 导视",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%AF%BC%E8%A7%86/61.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%AF%BC%E8%A7%86/61.png.webp",
        "label": "61",
        "caption": "文创 · 导视 · 61"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%AF%BC%E8%A7%86/%E5%AF%BC%E8%A7%86%E5%B2%A9%E6%B5%86aaaa.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E5%AF%BC%E8%A7%86/%E5%AF%BC%E8%A7%86%E5%B2%A9%E6%B5%86aaaa.jpg.webp",
        "label": "导视岩浆aaaa",
        "caption": "文创 · 导视 · 导视岩浆aaaa"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "文创 · 手机支架",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E6%89%8B%E6%9C%BA%E6%94%AF%E6%9E%B6/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_51_45.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E6%89%8B%E6%9C%BA%E6%94%AF%E6%9E%B6/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_51_45.png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_51_45",
        "caption": "文创 · 手机支架 · ChatGPT Image 2026年9月11日 21_51_45"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "文创 · 陶瓷文创",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/1.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/1.png.webp",
        "label": "1",
        "caption": "文创 · 陶瓷文创 · 1"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/85fea76787056bb3312e0f4ea47ad37.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/85fea76787056bb3312e0f4ea47ad37.png.webp",
        "label": "85fea76787056bb3312e0f4ea47ad37",
        "caption": "文创 · 陶瓷文创 · 85fea76787056bb3312e0f4ea47ad37"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/89f8112545c9a772eaded531f35d8b5.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/89f8112545c9a772eaded531f35d8b5.jpg.webp",
        "label": "89f8112545c9a772eaded531f35d8b5",
        "caption": "文创 · 陶瓷文创 · 89f8112545c9a772eaded531f35d8b5"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/211.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/211.png.webp",
        "label": "211",
        "caption": "文创 · 陶瓷文创 · 211"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/5455.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/5455.png.webp",
        "label": "5455",
        "caption": "文创 · 陶瓷文创 · 5455"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/12548.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/12548.png.webp",
        "label": "12548",
        "caption": "文创 · 陶瓷文创 · 12548"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/262626.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/262626.png.webp",
        "label": "262626",
        "caption": "文创 · 陶瓷文创 · 262626"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/2626262.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/2626262.png.webp",
        "label": "2626262",
        "caption": "文创 · 陶瓷文创 · 2626262"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/5262652626262.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E9%99%B6%E7%93%B7%E6%96%87%E5%88%9B/5262652626262.png.webp",
        "label": "5262652626262",
        "caption": "文创 · 陶瓷文创 · 5262652626262"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "文创 · 物料",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E7%89%A9%E6%96%99/%E5%AE%A0%E7%89%A9%E9%97%BA%E8%9C%9C%E7%BA%A7%E8%BE%B9%E6%A1%86.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E7%89%A9%E6%96%99/%E5%AE%A0%E7%89%A9%E9%97%BA%E8%9C%9C%E7%BA%A7%E8%BE%B9%E6%A1%86.png.webp",
        "label": "宠物闺蜜级边框",
        "caption": "文创 · 物料 · 宠物闺蜜级边框"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E7%89%A9%E6%96%99/%E4%B8%8A%E6%96%99%E6%9C%BA%E5%8D%95%E9%A1%B5.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E7%89%A9%E6%96%99/%E4%B8%8A%E6%96%99%E6%9C%BA%E5%8D%95%E9%A1%B5.jpg.webp",
        "label": "上料机单页",
        "caption": "文创 · 物料 · 上料机单页"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E7%89%A9%E6%96%99/%E6%AD%A6%E5%A4%B7%E5%B1%B1%E6%97%85%E6%8B%8D%E6%9C%BA2.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E6%96%87%E5%88%9B/%E7%89%A9%E6%96%99/%E6%AD%A6%E5%A4%B7%E5%B1%B1%E6%97%85%E6%8B%8D%E6%9C%BA2.png.webp",
        "label": "武夷山旅拍机2",
        "caption": "文创 · 物料 · 武夷山旅拍机2"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "小怪兽nft",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E5%B0%8F%E6%80%AA%E5%85%BDnft/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2022_11_10.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E5%B0%8F%E6%80%AA%E5%85%BDnft/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2022_11_10.png.webp",
        "label": "ChatGPT Image 2026年9月11日 22_11_10",
        "caption": "小怪兽nft · ChatGPT Image 2026年9月11日 22_11_10"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "字体设计",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E5%AD%97%E4%BD%93%E8%AE%BE%E8%AE%A1/123223.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/%E5%AD%97%E4%BD%93%E8%AE%BE%E8%AE%A1/123223.png.webp",
        "label": "123223",
        "caption": "字体设计 · 123223"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "iP · 蝶影相机",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E8%9D%B6%E5%BD%B1%E7%9B%B8%E6%9C%BA/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_23_55.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E8%9D%B6%E5%BD%B1%E7%9B%B8%E6%9C%BA/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_23_55.png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_23_55",
        "caption": "iP · 蝶影相机 · ChatGPT Image 2026年9月11日 21_23_55"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E8%9D%B6%E5%BD%B1%E7%9B%B8%E6%9C%BA/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_07%20(5).png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E8%9D%B6%E5%BD%B1%E7%9B%B8%E6%9C%BA/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_07%20(5).png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_36_07 (5)",
        "caption": "iP · 蝶影相机 · ChatGPT Image 2026年9月11日 21_36_07 (5)"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E8%9D%B6%E5%BD%B1%E7%9B%B8%E6%9C%BA/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_08%20(6).png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E8%9D%B6%E5%BD%B1%E7%9B%B8%E6%9C%BA/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_08%20(6).png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_36_08 (6)",
        "caption": "iP · 蝶影相机 · ChatGPT Image 2026年9月11日 21_36_08 (6)"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "iP · 夜游神",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E5%A4%9C%E6%B8%B8%E7%A5%9E/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_09_59.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E5%A4%9C%E6%B8%B8%E7%A5%9E/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_09_59.png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_09_59",
        "caption": "iP · 夜游神 · ChatGPT Image 2026年9月11日 21_09_59"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E5%A4%9C%E6%B8%B8%E7%A5%9E/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_04%20(1).png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E5%A4%9C%E6%B8%B8%E7%A5%9E/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_04%20(1).png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_36_04 (1)",
        "caption": "iP · 夜游神 · ChatGPT Image 2026年9月11日 21_36_04 (1)"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E5%A4%9C%E6%B8%B8%E7%A5%9E/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_04%20(2).png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E5%A4%9C%E6%B8%B8%E7%A5%9E/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_04%20(2).png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_36_04 (2)",
        "caption": "iP · 夜游神 · ChatGPT Image 2026年9月11日 21_36_04 (2)"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "iP · 中瑞ip",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E4%B8%AD%E7%91%9Eip/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_17_19.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E4%B8%AD%E7%91%9Eip/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_17_19.png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_17_19",
        "caption": "iP · 中瑞ip · ChatGPT Image 2026年9月11日 21_17_19"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E4%B8%AD%E7%91%9Eip/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_05%20(3).png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E4%B8%AD%E7%91%9Eip/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_05%20(3).png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_36_05 (3)",
        "caption": "iP · 中瑞ip · ChatGPT Image 2026年9月11日 21_36_05 (3)"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E4%B8%AD%E7%91%9Eip/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_06%20(4).png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/%E4%B8%AD%E7%91%9Eip/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_06%20(4).png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_36_06 (4)",
        "caption": "iP · 中瑞ip · ChatGPT Image 2026年9月11日 21_36_06 (4)"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "iP · genki",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/genki/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_29_13.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/genki/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_29_13.png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_29_13",
        "caption": "iP · genki · ChatGPT Image 2026年9月11日 21_29_13"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/genki/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_09%20(7).png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/genki/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_09%20(7).png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_36_09 (7)",
        "caption": "iP · genki · ChatGPT Image 2026年9月11日 21_36_09 (7)"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/genki/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_09%20(8).png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/iP/genki/ChatGPT%20Image%202026%E5%B9%B49%E6%9C%8811%E6%97%A5%2021_36_09%20(8).png.webp",
        "label": "ChatGPT Image 2026年9月11日 21_36_09 (8)",
        "caption": "iP · genki · ChatGPT Image 2026年9月11日 21_36_09 (8)"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "kv",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/1%E6%96%87%E5%8C%96%E5%A2%99cmyk%E5%A4%A7%E5%B0%BA%E5%AF%B8_%E7%94%BB%E6%9D%BF%201.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/1%E6%96%87%E5%8C%96%E5%A2%99cmyk%E5%A4%A7%E5%B0%BA%E5%AF%B8_%E7%94%BB%E6%9D%BF%201.jpg.webp",
        "label": "1文化墙cmyk大尺寸_画板 1",
        "caption": "kv · 1文化墙cmyk大尺寸_画板 1"
      }
    ],
    "tags": []
  },
  {
    "category": "brand",
    "title": "光伏展会视觉系统",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E4%BA%A7%E5%93%81%E4%BB%8B%E7%BB%8D.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E4%BA%A7%E5%93%81%E4%BB%8B%E7%BB%8D.png.webp",
        "label": "产品介绍",
        "caption": "光伏展会视觉系统 · 产品介绍"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E4%BA%A7%E5%93%81%E7%9F%A9%E9%98%B5.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E4%BA%A7%E5%93%81%E7%9F%A9%E9%98%B5.png.webp",
        "label": "产品矩阵",
        "caption": "光伏展会视觉系统 · 产品矩阵"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E6%9E%84%E6%9E%B6%E5%9B%BE%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A%E6%B5%B7%E6%8A%A5.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E6%9E%84%E6%9E%B6%E5%9B%BE%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A%E6%B5%B7%E6%8A%A5.png.webp",
        "label": "构架图光伏展会海报",
        "caption": "光伏展会视觉系统 · 构架图光伏展会海报"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A%E4%BB%8B%E7%BB%8D%E3%80%81%E5%A5%96%E9%A1%B92.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A%E4%BB%8B%E7%BB%8D%E3%80%81%E5%A5%96%E9%A1%B92.png.webp",
        "label": "光伏展会介绍、奖项2",
        "caption": "光伏展会视觉系统 · 光伏展会介绍、奖项2"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E6%A0%B8%E5%BF%83%E5%B7%A5%E4%B8%9A%E8%83%BD%E5%8A%9B.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/%E6%A0%B8%E5%BF%83%E5%B7%A5%E4%B8%9A%E8%83%BD%E5%8A%9B.png.webp",
        "label": "核心工业能力",
        "caption": "光伏展会视觉系统 · 核心工业能力"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/aoi%E6%A3%80%E6%B5%8B%E4%B8%93%E5%AE%B6.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/kv/%E5%85%89%E4%BC%8F%E5%B1%95%E4%BC%9A/aoi%E6%A3%80%E6%B5%8B%E4%B8%93%E5%AE%B6.png.webp",
        "label": "aoi检测专家",
        "caption": "光伏展会视觉系统 · aoi检测专家"
      }
    ],
    "tags": [
      "展会主视觉",
      "产品矩阵",
      "工业品牌"
    ]
  },
  {
    "category": "brand",
    "title": "Logo 与 VI 标志设计",
    "images": [
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/120221027%3D%E6%AC%A2%E9%93%B6%E7%94%B5%E5%BD%B1.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/120221027%3D%E6%AC%A2%E9%93%B6%E7%94%B5%E5%BD%B1.png.webp",
        "label": "120221027=欢银电影",
        "caption": "Logo 与 VI 标志设计 · 120221027=欢银电影"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E6%97%97%E5%B8%9C%E6%B5%85%E8%93%9D1.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E6%97%97%E5%B8%9C%E6%B5%85%E8%93%9D1.jpg.webp",
        "label": "旗帜浅蓝1",
        "caption": "Logo 与 VI 标志设计 · 旗帜浅蓝1"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E9%80%8F%E6%98%8E.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E9%80%8F%E6%98%8E.png.webp",
        "label": "透明",
        "caption": "Logo 与 VI 标志设计 · 透明"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E6%9C%AA%E6%A0%87%E9%A2%98-1_%E7%94%BB%E6%9D%BF%201_%E7%94%BB%E6%9D%BF%201.jpg.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E6%9C%AA%E6%A0%87%E9%A2%98-1_%E7%94%BB%E6%9D%BF%201_%E7%94%BB%E6%9D%BF%201.jpg.webp",
        "label": "未标题-1_画板 1_画板 1",
        "caption": "Logo 与 VI 标志设计 · 未标题-1_画板 1_画板 1"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E6%9C%AA%E6%A0%87%E9%A2%98-34.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E6%9C%AA%E6%A0%87%E9%A2%98-34.png.webp",
        "label": "未标题-34",
        "caption": "Logo 与 VI 标志设计 · 未标题-34"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E6%9C%AA%E6%A0%87%E9%A2%98-35.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/%E6%9C%AA%E6%A0%87%E9%A2%98-35.png.webp",
        "label": "未标题-35",
        "caption": "Logo 与 VI 标志设计 · 未标题-35"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/Mockup%20by%20Mithun%20Mitra.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/Mockup%20by%20Mithun%20Mitra.png.webp",
        "label": "Mockup by Mithun Mitra",
        "caption": "Logo 与 VI 标志设计 · Mockup by Mithun Mitra"
      },
      {
        "src": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/vi%E8%B0%A2%E8%B0%A2%E4%BD%A0-07.png.webp",
        "thumb": "assets/library-import/%E5%93%81%E7%89%8C%E8%AE%BE%E8%AE%A1/logo/vi%E8%B0%A2%E8%B0%A2%E4%BD%A0-07.png.webp",
        "label": "vi谢谢你-07",
        "caption": "Logo 与 VI 标志设计 · vi谢谢你-07"
      }
    ],
    "tags": [
      "标志设计",
      "品牌识别",
      "应用延展"
    ]
  },
  {
    "category": "aigc",
    "title": "AI 自动化视觉生成",
    "pages": [
      48,
      49,
      50,
      51,
      52,
      53
    ],
    "tags": [
      "AI 生成",
      "风格控制",
      "后期整合"
    ]
  },
  {
    "category": "aigc",
    "title": "AI + B 端图标",
    "pages": [
      54,
      55
    ],
    "tags": [
      "图标设计",
      "B 端视觉",
      "AI 协同"
    ]
  },
  {
    "category": "aigc",
    "title": "AI 辅助 3D 素材",
    "pages": [
      56
    ],
    "tags": [
      "3D 素材",
      "场景搭建",
      "效率提升"
    ]
  },
  {
    "category": "practice",
    "title": "个人练习",
    "pages": [
      57,
      58,
      59,
      60,
      61,
      62,
      63
    ],
    "tags": [
      "视觉实验",
      "风格探索",
      "表现力"
    ]
  }
];

const projectRoot = document.querySelector("#featured-projects");
const projectIndex = document.querySelector("#project-index");
const archiveRoot = document.querySelector("#archive-grid");
const lightbox = document.querySelector("#lightbox");
const lightboxImg = lightbox.querySelector("img");
const lightboxCaption = lightbox.querySelector("p");
const closeLightbox = lightbox.querySelector(".lightbox-close");
const lightboxPrev = lightbox.querySelector(".lightbox-prev");
const lightboxNext = lightbox.querySelector(".lightbox-next");
const archiveSummary = document.querySelector("#archive-summary");
const agent = document.querySelector(".portfolio-agent");

let previewItems = [];
let previewIndex = 0;

function updateLightbox() {
  const item = previewItems[previewIndex];
  if (!item) return;
  lightboxImg.src = item.src;
  lightboxImg.alt = item.caption;
  lightboxCaption.textContent = `${item.caption} · ${previewIndex + 1}/${previewItems.length}`;
  const hasMultiple = previewItems.length > 1;
  lightboxPrev.hidden = !hasMultiple;
  lightboxNext.hidden = !hasMultiple;
}

function openPreview(items, index = 0) {
  previewItems = Array.isArray(items) ? items : [items];
  previewIndex = index;
  updateLightbox();
  if (typeof lightbox.showModal === "function") {
    lightbox.showModal();
  } else {
    lightbox.setAttribute("open", "");
  }
}

function movePreview(direction) {
  if (previewItems.length < 2) return;
  previewIndex = (previewIndex + direction + previewItems.length) % previewItems.length;
  updateLightbox();
}

function galleryButton(item, gallery, index) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "magnetic";
  button.innerHTML = `
    <img loading="lazy" src="${item.thumb}" alt="${item.caption}">
    <span>${item.label}</span>
  `;
  button.addEventListener("click", () => openPreview(gallery, index));
  return button;
}

function renderProjects() {
  projectRoot.innerHTML = "";
  if (projectIndex) {
    projectIndex.innerHTML = projects
      .map(
        (project) => `
          <a class="project-pill" href="#${project.id}">
            <i class="project-pill-fill" aria-hidden="true"></i>
            <span class="project-pill-track">
              <span class="project-pill-face">
                <b>${project.number}</b>
                <strong>${project.title}</strong>
                <em>${project.type}</em>
              </span>
              <span class="project-pill-face project-pill-face-hover" aria-hidden="true">
                <b>${project.number}</b>
                <strong>${project.title}</strong>
                <em>查看完整案例</em>
              </span>
            </span>
          </a>
        `,
      )
      .join("");
  }
  projects.forEach((project, projectIndexNumber) => {
    const article = document.createElement("article");
    article.className = "project reveal";
    article.id = project.id;
    article.style.setProperty("--project-accent", projectIndexNumber === 1 ? "var(--cyan)" : "var(--magenta)");
    article.style.setProperty("--project-accent-rgb", projectIndexNumber === 1 ? "34, 215, 255" : "255, 62, 224");

    const hero = document.createElement("button");
    hero.className = "project-cover";
    hero.type = "button";
    hero.innerHTML = `
      <img loading="lazy" src="${project.cover}" alt="${project.title} 章节封面">
      <span>${project.number}</span>
      <small>OPEN CASE</small>
    `;
    hero.addEventListener("click", () => openPreview({ src: project.cover, caption: `${project.title} · 项目封面` }));

    const copy = document.createElement("div");
    copy.className = "project-copy";
    copy.innerHTML = `
      <span class="project-kicker">${project.number} · ${project.type}</span>
      <h3>${project.title}</h3>
      <p class="project-summary">${project.summary}</p>
      <ul class="project-facts">${project.facts.map((item) => `<li>${item}</li>`).join("")}</ul>
      <details class="project-strategy">
        <summary>设计策略</summary>
        <ul class="project-points">${project.points.map((item) => `<li>${item}</li>`).join("")}</ul>
      </details>
    `;

    const gallery = document.createElement("div");
    gallery.className = "project-gallery";
    const galleryItems = [...(project.concepts || []), ...project.pages.map((pageNumber, index) => ({
      src: page(pageNumber),
      thumb: page(pageNumber, "thumb"),
      caption: `${project.title} · P${String(pageNumber).padStart(2, "0")}`,
      label: project.labels?.[index] || `P${String(pageNumber).padStart(2, "0")}`,
    }))];
    const galleryStart = project.concepts ? 0 : 1;
    galleryItems.slice(galleryStart, galleryStart + 3).forEach((item, index) => {
      const button = galleryButton(item, galleryItems, index + galleryStart);
      button.style.setProperty("--gallery-order", index);
      gallery.append(button);
    });
    if (project.id === "project-aigc") {
      gallery.classList.add("aigc-directions");
      gallery.replaceChildren();
      const select = (...sources) => sources.map((src) => galleryItems.find((item) => item.src === src)).filter(Boolean);
      const groups = [
        { title: "3D 潮玩手办", description: "魔力手办 / 人物与角色 / 潮玩概念", items: select("assets/aigc-toy-cover-v2.jpg.webp", ...Array.from({ length: 7 }, (_, i) => `assets/aigc-figure-${i + 1}.png.webp`), "assets/aigc-toy-concept.jpg.webp") },
        { title: "包装设计", description: "瓶器 / 纸盒展开 / 品牌应用", items: select("assets/aigc-packaging-layout.png.webp", "assets/aigc-packaging-concept.jpg.webp", "assets/aigc-fragrance-concept.png.webp") },
        { title: "游戏视觉设计", description: "游戏 UI / 宣发主视觉 / 角色设定 / 场景", items: select("assets/aigc-game-ui.jpg.webp", "assets/aigc-game-promo.jpg.webp", "assets/aigc-game-character.jpg.webp", "assets/aigc-game-concept.jpg.webp") },
        { title: "商业视觉生成", description: "香氛主视觉 / 运动广告", items: select("assets/aigc-fragrance-concept.png.webp", "assets/aigc-sport-concept.png.webp") },
        { title: "B 端图标", description: "12 枚效率工具图标 / 原有图标与界面应用", items: select("assets/aigc-icons-v2.jpg.webp", page(54), page(55)) },
        { title: "素材与应用场景", description: "电商展台与配套素材 / 原有场景与角色", items: select("assets/aigc-applications-v2.jpg.webp", page(56), page(53)) },
      ];
      groups.forEach((group) => {
        const entry = document.createElement("div");
        entry.className = "aigc-direction";
        entry.append(galleryButton({ ...group.items[0], label: group.title }, group.items, 0));
        const description = document.createElement("p");
        description.textContent = group.description;
        entry.append(description);
        gallery.append(entry);
      });
    }

    const actions = document.createElement("div");
    actions.className = "project-actions";
    actions.innerHTML = `
      ${
        project.prototype
          ? `<a class="project-prototype-link" href="${project.prototype.href}" target="_blank" rel="noopener">${project.prototype.label}<span aria-hidden="true">↗</span></a>`
          : ""
      }
      <button type="button">查看全部作品 · ${galleryItems.length} 张</button>
    `;
    actions.querySelector("button").addEventListener("click", () => openPreview(galleryItems, 0));

    article.append(hero, copy, gallery, actions);
    projectRoot.append(article);
  });
}

function renderArchive() {
  archiveRoot.innerHTML = "";
  const sections = {};
  const panels = [];
  const order = ["ops", "ui", "brand"];
  order.forEach((category) => {
    const section = document.createElement("section");
    section.className = "archive-section";
    section.id = `archive-${category}`;
    const count = category === "brand" ? 6 : archiveItems.filter(item => item.category === category).length;
    section.innerHTML = `<button type="button" class="archive-category-cover" aria-expanded="false" aria-controls="archive-panel-${category}" id="archive-toggle-${category}"><img src="assets/archive-cover-${category}.jpg.webp" loading="lazy" alt=""><div><h3>${categories[category].label}</h3><span>${count} 组作品 · 点击展开</span><b aria-hidden="true">+</b></div></button>`;
    const panel = document.createElement("div");
    panel.id = `archive-panel-${category}`;
    panel.className = "archive-panel";
    panel.hidden = true;
    panel.setAttribute("role", "region");
    panel.setAttribute("aria-labelledby", `archive-heading-${category}`);
    panel.innerHTML = `<div class="archive-panel-heading"><h3 id="archive-heading-${category}">${categories[category].label}</h3></div><div class="archive-section-grid"></div><div class="archive-panel-footer"><button type="button">收起作品 ↑</button></div>`;
    section.querySelector("button").addEventListener("click", () => applyArchiveFilter(panel.hidden ? category : "all"));
    panel.querySelector("button").addEventListener("click", () => {
      applyArchiveFilter("all");
      section.querySelector("button").focus({ preventScroll: true });
      section.scrollIntoView({ behavior: "instant", block: "start" });
    });
    sections[category] = panel;
    panels.push(panel);
    archiveRoot.append(section);
  });
  archiveRoot.append(...panels);
  const brandSeries = [
    { title: "品牌标志与字体", match: title => /Logo|字体/.test(title) },
    { title: "品牌主视觉与海报", match: title => /海报|^kv$|光伏/.test(title) },
    { title: "品牌手册", match: title => /手册/.test(title) },
    { title: "IP 角色设计", match: title => /^iP|小怪兽/.test(title) },
    { title: "表情包设计", match: title => /^表情包/.test(title) },
    { title: "文创与品牌应用", match: title => /^文创/.test(title) },
  ];
  brandSeries.forEach(series => {
    const details = document.createElement("section");
    details.className = "brand-series";
    details.innerHTML = `<h4 class="brand-series-heading">${series.title}</h4><div class="brand-series-projects"></div>`;
    series.element = details;
    sections.brand.querySelector(".archive-section-grid").append(details);
  });
  archiveItems.forEach((item) => {
    if (!sections[item.category]) return;
    const card = document.createElement("button");
    card.type = "button";
    card.className = "archive-card";
    card.dataset.category = item.category;
    const galleryItems = item.images || item.pages.map((pageNumber) => ({
      src: page(pageNumber),
      thumb: page(pageNumber, "thumb"),
      caption: `${item.title} · P${String(pageNumber).padStart(2, "0")}`,
    }));
    const firstImage = galleryItems[0];
    const displayTitle = item.category !== "brand" ? item.title : ({
      "iP · 中瑞ip": "中瑞 IP 角色设计", "iP · genki": "Genki IP 角色设计",
      "iP · 蝶影相机": "蝶影相机 IP 角色设计", "iP · 夜游神": "夜游神 IP 角色设计",
      "小怪兽nft": "小怪兽 IP 角色设计", "kv": "文化墙主视觉设计",
      "手册 · vi手册": "VI 品牌手册", "手册 · 也有神书": "也有神书 · 手册设计",
      "手册导出图": "明眸品牌手册", "文创 · 物料": "文创周边物料",
    }[item.title] || item.title.replace(/^文创 · /, "").replace(/^表情包 · (.+) · 2d$/, "$1 · 2D 表情包").replace(/^表情包 · (.+) · 3d$/, "$1 · 3D 表情包").replace(/^表情包 · (.+)$/, "$1表情包"));
    card.innerHTML = `
      <figure>
        <div class="thumb"><img loading="lazy" src="${item.cover || firstImage.thumb}" alt="${item.title}"></div>
        <figcaption>
          <small>${categories[item.category].label}</small>
          <strong>${displayTitle}</strong>
          <span>${galleryItems.length} 张 · 项目作品集</span>
          <div class="archive-tags">${(item.tags || []).map(tag => `<em>${tag}</em>`).join("")}</div>
        </figcaption>
      </figure>
    `;
    card.addEventListener("click", () => openPreview(galleryItems, 0));
    if (item.category === "brand") {
      brandSeries.find(series => series.match(item.title)).element.querySelector(".brand-series-projects").append(card);
    } else sections[item.category].querySelector(".archive-section-grid").append(card);
  });
}

function setupFilters() {
  const counts = archiveItems.reduce(
    (acc, item) => {
      acc.all += 1;
      acc[item.category] = (acc[item.category] || 0) + 1;
      return acc;
    },
    { all: 0 },
  );
  document.querySelectorAll(".filter").forEach((button) => {
    button.dataset.count = counts[button.dataset.filter] || 0;
    button.setAttribute("aria-selected", button.classList.contains("active") ? "true" : "false");
  });

  document.querySelectorAll(".filter").forEach((button) => {
    button.addEventListener("click", () => {
      applyArchiveFilter(button.dataset.filter);
    });
  });

  document.querySelectorAll("[data-filter-link]").forEach((link) => {
    link.addEventListener("click", () => {
      window.setTimeout(() => applyArchiveFilter(link.dataset.filterLink), 120);
    });
  });
}

let archiveLimit = 6;
let currentArchiveFilter = "all";
document.querySelector("#archive-more").addEventListener("click", () => {
  archiveLimit += 6;
  applyArchiveFilter(currentArchiveFilter, true);
});

function applyArchiveFilter(filter, keepLimit = false) {
  document.querySelectorAll(".archive-section").forEach(section => {
    const active = section.id === `archive-${filter}`;
    const button = section.querySelector("button");
    button.setAttribute("aria-expanded", String(active));
    button.querySelector("b").textContent = active ? "−" : "+";
    const panel = document.getElementById(button.getAttribute("aria-controls"));
    panel.hidden = !active;
    const count = panel.querySelectorAll(".brand-series").length || panel.querySelectorAll(".archive-card").length;
    button.querySelector("span").textContent = `${count} 组作品 · ${active ? "点击收起" : "点击展开"}`;
  });
  document.querySelector("#archive-more").hidden = true;
}

function setupScrollProgress() {
  const bar = document.querySelector(".scroll-progress span");
  if (!bar) return;
  const update = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const progress = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
    bar.style.transform = `scaleX(${progress})`;
  };
  update();
  window.addEventListener("scroll", update, { passive: true });
  window.addEventListener("resize", update);
}

function setupProjectIndex() {
  if (!projectIndex) return;
  const links = [...projectIndex.querySelectorAll("a")];
  const sections = links.map((link) => document.querySelector(link.getAttribute("href"))).filter(Boolean);
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        links.forEach((link) => link.classList.toggle("is-current", link.getAttribute("href") === `#${entry.target.id}`));
      });
    },
    { rootMargin: "-24% 0px -58% 0px", threshold: 0 },
  );
  sections.forEach((section) => observer.observe(section));
}

function setupProjectPills() {
  if (!projectIndex) return;
  const pills = [...projectIndex.querySelectorAll(".project-pill")];
  const layout = () => {
    pills.forEach((pill) => {
      const fill = pill.querySelector(".project-pill-fill");
      if (!fill) return;
      const { width, height } = pill.getBoundingClientRect();
      const radius = ((width * width) / 4 + height * height) / (2 * height);
      const diameter = Math.ceil(radius * 2) + 4;
      const delta = Math.ceil(radius - Math.sqrt(Math.max(0, radius * radius - (width * width) / 4))) + 2;
      fill.style.width = `${diameter}px`;
      fill.style.height = `${diameter}px`;
      fill.style.bottom = `-${delta}px`;
    });
  };
  layout();
  window.addEventListener("resize", layout);
  if (document.fonts?.ready) document.fonts.ready.then(layout).catch(() => {});
}

function setupReveal() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: "0px 0px -6% 0px" },
  );
  document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
}

function setupNavState() {
  const links = [...document.querySelectorAll(".nav-links a, .chapter-rail a")];
  const sections = links.map((link) => document.querySelector(link.getAttribute("href"))).filter(Boolean);
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        links.forEach((link) => link.classList.toggle("is-current", link.getAttribute("href") === `#${entry.target.id}`));
      });
    },
    { threshold: 0.38 },
  );
  sections.forEach((section) => observer.observe(section));
}

function setupCursor() {
  const cursor = document.querySelector(".cursor");
  if (!cursor || matchMedia("(pointer: coarse)").matches) return;

  window.addEventListener("pointermove", (event) => {
    cursor.style.opacity = "1";
    cursor.style.transform = `translate(${event.clientX}px, ${event.clientY}px) translate(-50%, -50%)`;
  });

  document.querySelectorAll("a, button, .magnetic").forEach((item) => {
    item.addEventListener("pointerenter", () => cursor.classList.add("is-active"));
    item.addEventListener("pointerleave", () => cursor.classList.remove("is-active"));
  });
}

function setupMagnetic() {
  if (matchMedia("(pointer: coarse)").matches) return;
  document.querySelectorAll(".magnetic").forEach((item) => {
    item.addEventListener("pointermove", (event) => {
      const rect = item.getBoundingClientRect();
      const x = (event.clientX - rect.left - rect.width / 2) * 0.12;
      const y = (event.clientY - rect.top - rect.height / 2) * 0.12;
      item.style.transform = `translate(${x}px, ${y}px)`;
    });
    item.addEventListener("pointerleave", () => {
      item.style.transform = "";
    });
  });
}

function setupBoardPreview() {
  document.querySelectorAll(".board-preview").forEach((button) => {
    button.addEventListener("click", () => {
      openPreview({ src: button.dataset.full, caption: button.dataset.caption });
    });
  });
}

const agentKnowledge = [
  {
    keys: ["你是谁", "是谁", "介绍", "阮华效", "run"],
    answer:
      "我是阮华效作品集里的 RUN 智能分身。阮华效是一名视觉设计师 / UID 设计师，作品集中重点展示运营视觉、营销视觉、品牌视觉、AI 视觉与产品界面设计能力。",
  },
  {
    keys: ["项目", "精选", "案例", "作品"],
    answer:
      "当前精选项目有 3 个：朴朴运营视觉系统、优久久电商平台 App、AIGC 视觉设计探索。它们分别对应运营活动视觉、产品 UI 体系和 AI 视觉生成能力。你可以从导航进入“精选”查看完整案例。",
  },
  {
    keys: ["运营", "营销", "banner", "活动", "朴朴"],
    answer:
      "运营视觉部分聚焦活动主视觉、促销专题、Banner、频道入口和私域海报。设计重点是快速建立活动记忆点，并把主视觉延展到多尺寸、多渠道物料。",
  },
  {
    keys: ["ui", "界面", "app", "优久久", "小程序", "产品"],
    answer:
      "UI 方向主要展示优久久电商 App 和小程序 / 网页项目，覆盖视觉规范、信息架构、首页、分类、购物车、个人中心等页面，体现从规范到核心页面矩阵的完整交付能力。",
  },
  {
    keys: ["ai", "aigc", "人工智能", "生成", "midjourney", "comfyui"],
    answer:
      "AIGC 方向展示的是把 AI 接入视觉流程的能力，包括风格探索、角色生成、B 端图标、3D 素材和后期整合。重点不是单张效果图，而是稳定产出可落地的视觉资产。",
  },
  {
    keys: ["品牌", "logo", "vi", "ip", "字体"],
    answer:
      "品牌方向包含 Logo、VI/IP、字体与商业海报延展。作品库里可以按“品牌”筛选，快速看到品牌识别和视觉资产延展能力。",
  },
  {
    keys: ["岗位", "求职", "适合", "方向", "职位"],
    answer:
      "求职方向聚焦视觉设计、运营视觉、营销视觉、品牌视觉、AI 视觉与产品界面相关岗位。更适合需要商业视觉判断、活动物料落地、界面视觉规范和新工具协同的团队。",
  },
  {
    keys: ["技能", "软件", "工具", "能力"],
    answer:
      "核心能力包括运营视觉、UI / 小程序界面、品牌 VI/IP、3D 视觉与 AIGC 高效创作。常用工具包括 Photoshop、Illustrator、C4D、Premiere、After Effects、Midjourney、Stable Diffusion、ComfyUI 和 ChatGPT。",
  },
  {
    keys: ["联系", "电话", "邮箱", "微信", "wechat", "email"],
    answer:
      "联系方式：电话 *** **** ****，邮箱 ********，微信 ********。也可以直接滚动到页面底部的联系区。",
  },
  {
    keys: ["目录", "分类", "作品库", "archive"],
    answer:
      "作品库按运营视觉、UI / 网页、品牌、AIGC、个人练习分类。看完精选项目后，可以进入作品库快速浏览更多场景和能力标签。",
  },
];

function getAgentAnswer(question) {
  const normalized = question.trim().toLowerCase();
  const matched = agentKnowledge.find((item) => item.keys.some((key) => normalized.includes(key.toLowerCase())));
  if (matched) return matched.answer;
  return "这个问题我可以从作品集角度回答：你可以问我“精选项目有哪些”“擅长什么岗位”“AIGC 能力是什么”“怎么联系”。如果想看具体作品，建议先看精选项目，再进入作品库按分类筛选。";
}

function setupPortfolioAgent() {
  if (!agent) return;
  const trigger = agent.querySelector(".agent-trigger");
  const panel = agent.querySelector(".agent-panel");
  const close = agent.querySelector(".agent-close");
  const messages = agent.querySelector(".agent-messages");
  const form = agent.querySelector(".agent-form");
  const input = form.querySelector("input");
  const quickButtons = agent.querySelectorAll("[data-agent-question]");

  function addMessage(role, text) {
    const bubble = document.createElement("div");
    bubble.className = `agent-message ${role}`;
    bubble.textContent = text;
    messages.append(bubble);
    messages.scrollTop = messages.scrollHeight;
  }

  function openAgent() {
    panel.hidden = false;
    trigger.setAttribute("aria-expanded", "true");
    agent.classList.add("is-open");
    if (!messages.children.length) {
      addMessage("bot", "你好，我可以帮你快速了解阮华效的项目、能力、求职方向和联系方式。");
    }
    window.setTimeout(() => input.focus(), 80);
  }

  function closeAgent() {
    panel.hidden = true;
    trigger.setAttribute("aria-expanded", "false");
    agent.classList.remove("is-open");
  }

  function ask(question) {
    const clean = question.trim();
    if (!clean) return;
    addMessage("user", clean);
    window.setTimeout(() => addMessage("bot", getAgentAnswer(clean)), 180);
  }

  trigger.addEventListener("click", () => {
    if (panel.hidden) openAgent();
    else closeAgent();
  });
  close.addEventListener("click", closeAgent);
  quickButtons.forEach((button) => {
    button.addEventListener("click", () => ask(button.dataset.agentQuestion));
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    ask(input.value);
    input.value = "";
  });
}

closeLightbox.addEventListener("click", () => lightbox.close());
lightboxPrev.addEventListener("click", () => movePreview(-1));
lightboxNext.addEventListener("click", () => movePreview(1));
lightbox.addEventListener("click", (event) => {
  if (event.target === lightbox) lightbox.close();
});
window.addEventListener("keydown", (event) => {
  if (!lightbox.open) return;
  if (event.key === "ArrowLeft") movePreview(-1);
  if (event.key === "ArrowRight") movePreview(1);
});

renderProjects();
renderArchive();
applyArchiveFilter("all");
setupFilters();
setupReveal();
setupNavState();
setupScrollProgress();
setupProjectIndex();
setupProjectPills();
setupCursor();
setupMagnetic();
setupBoardPreview();
setupPortfolioAgent();
